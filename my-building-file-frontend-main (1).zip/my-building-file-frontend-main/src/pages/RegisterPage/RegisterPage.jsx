import React from "react";
import "./registerPage.css";
import { useState } from "react";
import axios from "axios";
const url = 'http://admin.mybuildingfile.com/api/v1/manager/register';


const RegisterPage = () => {
  const [password, setPassword] = useState('')


     return (
              <div className="login_starts">
                <div className="login_side">
                  <div className="login_started">
                    <img src={process.env.PUBLIC_URL+"Logo.png"} alt="signin png"/>
                  </div>

                  <div className="form_heads">
                    <div className="form_tops">
                      <div className="form_signs">
                        <a href={process.env.PUBLIC_URL+"signin"}><h5 className="grill1">SIGN IN</h5></a>
                        <h5 className="grill2">SIGN UP</h5> 
                      </div>
                      <img className="trimm" src={process.env.PUBLIC_URL+"trim.png"} alt="trim png"/>
                    </div>
                    <div className="form_two">
                        <h6 className="form_intro_text">Welcome to Mybuildingfile</h6>
                        <h2 className="form_two_text">Create Your Password</h2>
                    </div>

                    <div className="form_detail">
                        <div className="form_props">
                        <img className="detail_text" src={process.env.PUBLIC_URL+"tick.png"} alt="details png"/>
                        <p className="detail_text_two">Personal Details</p>
                        </div>

                        <img className="loginvector" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow right png"/>   

                        <div className="form_props">
                        <img className="secured_img" src={process.env.PUBLIC_URL+"twoon.png"} alt="security png"/>
                        <p className="secured_text">Security</p>
                        </div>
                    </div>

                    <div className="form_boss">
                      <div className="fill_style">
                          <label for="pwd" className="form_text">Password</label>
                          <input className="area_style" type="password" name="pwd" id="pwd" placeholder="••••••••••" value={password} onChange={(e) => setPassword(e.target.value)}></input>
                      </div>

                      <div className="fill_style">
                          <label for="pwd" className="form_text">Confirm Password</label>
                          <input className="area_style" type="password" name="pwd" id="pwd" placeholder="••••••••••" ></input>
                          <a href={process.env.PUBLIC_URL+"resetpassword"} className="register_forgot"><p >Forgot Password</p></a>
                      </div>
                     
                    </div>

                    <a href={process.env.PUBLIC_URL+"registration"}  className="bttn" src=""><h6 className="bttn_txt">Next</h6></a>
                 <p className="term">By clicking the button, you agree to our <a href="#">Terms of Service</a> and have read and acknowledged our <a href="#">Privacy Policy</a></p>
                 <p className="slim">Don’t have an account yet? <a href={process.env.PUBLIC_URL+"signup"}>Sign Up</a></p>


                  </div>
                </div>

                <div className="login_side second">
                  <img className="illustrate" src={process.env.PUBLIC_URL+"sign up ill.png"} alt="signin png"/>
                </div>

              </div>

    );
};

export default RegisterPage;
