import React from "react";
import "./RegistrationSuccess.css";

const RegistrationSuccess = () => {
    return (
        <div className="register">
            <div className="reg_wrapper">
                <div className="reg_item">
                <img src={process.env.PUBLIC_URL+"regsuccess.png"} alt="success_png"/>
                </div>
                <div className="reg_item">
                <h5 className="reg_success">Registration Successful</h5>
                </div>
                <div className="reg_item">
                <p className="text_success">You can now log into your account and explore the best experience with your properties</p>
                </div>
                <div className="reg_item">
                <a href={process.env.PUBLIC_URL+"homelandlord"}>
                    <button className="btn" type="button"><h6 className="btn_text">Proceed</h6> </button>
                </a>
                
                </div>
            </div>
        </div>

    );
};

export default RegistrationSuccess;