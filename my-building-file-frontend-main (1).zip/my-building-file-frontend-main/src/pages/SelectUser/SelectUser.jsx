import React from "react";
import "./SelectUser.css";

const SelectUser = () => {
  return (
        <div className="Users">
            <div className="Select">
              <a className="select_logo" href=""><img src={process.env.PUBLIC_URL+"Logo.png"} alt="logo-png"/></a>
                  <div className="Select_flow">
                      <div className="flow">
                        <p className="flow_text">Welcome to MyBuildinglife</p>
                        <h2 className="flow_text_two">Select what type of property you’re managing </h2>
                      </div>

                      <div className="flow_illustration">
                      <a className="flow_img" href={process.env.PUBLIC_URL+"selectuser2"}><img src={process.env.PUBLIC_URL+"Residential.png"} alt="residential-png"/></a>
                      <a className="flow_img_two" href={process.env.PUBLIC_URL+"selectuser3"}><img src={process.env.PUBLIC_URL+"Commercial.png"} alt="commercial-png"/></a>
                      </div>
                      <a className="flow_button" src=""><h6 className="flow_txt">Continue</h6></a>
                  </div>

            </div>
                    <div className="Frame">
                    <img className="Frame_ill" src={process.env.PUBLIC_URL+"Frame.png"} alt="frame-png"/>
                    </div>
        </div> 
  );
};

export default SelectUser;