import React from "react";
import "./homeLandlord.css";

const Homelandlord = () => {
    return (
        <div className="home_container">
            <div className="homelandlord_main">
                <a className="main_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                    <div className="sidebar">
                        <div className="sidebar_list">
                            <div className="sidebar_item1">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home active.svg"} alt="home png"/></a>
                            </div>
                            <div className="sidebar_item2" >
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties png"/></a>
                            </div>
                            <div className="sidebar_item3">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                            </div>
                            <div className="sidebar_item4">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                            </div>
                            <div className="sidebar_item5">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                            </div>
                            <div className="sidebar_item6">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                            </div>
                            <div className="sidebar_item7">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                            </div>
                            
                        </div>
                            <div className="sidebar_logout">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                            </div>
                            

                    </div>
                </div>
                <div className="content">
                            <div className="content_top">
                                <p className="top_text">Mon, 12th Nov 2022</p>
                                <h3 className="top_greet">Hello, <b>Andrew</b></h3>
                            </div>


                            <div className="message_notification">
                                <div className="messages_notif_wrapper">
                                    <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                        <div className="msg_wrapper">
                                            <h6 className="msg_wrapper_text">Hendrix James</h6>
                                            <p className="msg_wrapper_text2">Property Manager</p>
                                        </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"signin"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                            <div className="Rent">
                                <h5 className="rent_text">Rent Statistics</h5>
                                <p className="rent_over">Showing overview from Oct 2022 - Nov 2022 </p>
                                    <div className="rent_calender">
                                        <p className="rent_img">📅</p>
                                        <p className="rent_date">Oct 1 - Nov 12</p>
                                    </div>
                                    <div className="units">
                                        <div className="unit_case">
                                            <img className="unit_img1" src={process.env.PUBLIC_URL+"home icon.svg"} alt="home ill" />
                                            <p className="text_unit">Total Units</p>
                                            <h3 className="text_unit_two">54</h3>
                                            <img className="unit_img2" src={process.env.PUBLIC_URL+"trim3.png"} alt="trim3 png"/>
                                            <div className="unit_available">
                                                <img className="unit_avail_img" src={process.env.PUBLIC_URL+"house empty.svg"} alt="trim3 png"/>
                                                <p className="unit_avail_text">8 available</p>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="total">
                                        <div className="total_case">
                                            <div className="text_total">
                                                <p className="total_text">Total rent</p>
                                                <h3 className="total_text2">₦ 4,500,000</h3>
                                            </div>
                                            <img className="total_img" src={process.env.PUBLIC_URL+"trim3.png"} alt="trim ill" />
                                                <div className="total_end_case">

                                                    <div className="total_collect">
                                                        <p className="total_collect_text">Collected</p>
                                                        <h6 className="total_collect_text2">₦ 1,200,000</h6>
                                                    </div>

                                                    <div className="total_end">
                                                        <p className="total_end_text">Pending</p>
                                                        <h6 className="total_end_text2">₦ 3,300,000</h6>
                                                    </div>
                                                </div>
                                        </div>

                                    </div>
                            </div>
                                            <div className="Properties">
                                                <a href={process.env.PUBLIC_URL+"tenant"}><p className="text_bold">See all properties</p></a>
                                                <div className="properties_case">
                                                <img className="properties_img" src={process.env.PUBLIC_URL+"tray.svg"} alt="tray ill" />
                                                    <div className="properties_font">
                                                        <h3 className="properties_font_text">54</h3>
                                                        <p className="properties_font_text2">Properties</p>
                                                    </div>

                                                </div>

                                                <div className="property_box">
                                                    <div className="property_first">
                                                     <img className="property_img" src={process.env.PUBLIC_URL+"tray2.svg"} alt="tray2 ill" /> 

                                                        <div className="property_last">
                                                            <h4 className="property_last_text">12</h4>
                                                            <p className="property_last_text2">Occupied</p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="vacant_box">
                                                    <div className="vacant_first">
                                                        <img className="vacant_img" src={process.env.PUBLIC_URL+"tray3.svg"} alt="tray3 ill" /> 
                                                            <div className="vacant_last">
                                                                <h4 className="vacant_last_text">8</h4>
                                                                <p className="vacant_last_text2">Vacant</p>
                                                            </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="Warning" >
                                                <img className="warning_img" src={process.env.PUBLIC_URL+"info-circle.png"} alt="info-circle ill" />
                                                <p className="warning_text">3 Properties will be vacant at the end of the month</p>
                                            </div>

                                   <div className="homelandlord_bigg_setion">
                                       <img className="bigg_section_img" src={process.env.PUBLIC_URL+"bigg.svg"} alt="section ill png" />

                                        <div className="homelandlord_transact">
                                                    <h5 className="transact_text">All Transaction</h5>
                                                    <p className="transact_text1">Date</p>
                                                    <p className="transact_text2">Property</p>
                                                    <p className="transact_text3">Sender</p>
                                                    <p className="transact_text4">Bill</p>
                                                    <p className="transact_text5">Amount</p>
                                                    <p className="transact_text6">Status</p>

                                                        <div className="transact_table">
                                                            <div className="transact_case">  
                                                                <div className="table_case">
                                                                    <div className="case_table">
                                                                        <p className="table_case_text">20th June 22</p>
                                                                    </div>

                                                                </div>

                                                                <div className="beverly_transact">
                                                                    <img className="transact_img" src={process.env.PUBLIC_URL+"Ellipse 13.png"} alt="ellipse ill" />
                                                                        <div className="beverly_case">
                                                                            <p className="beverly_case_text">Beverly Hills</p>
                                                                            <p className="beverly_case_text2">Lagos, Nigeria</p>
                                                                        </div>
                                                                </div>
                                                                <div className="josh_transact">
                                                                     <img className="transact_img2" src={process.env.PUBLIC_URL+"Ellipse 14.png"} alt="ellipse ill png" />
                                                                        <div className="josh_case">
                                                                            <p className="josh_case_text">Josh Andrew</p>
                                                                        </div>
                                                                </div>

                                                                <div className="water_transact">
                                                                    <div className="water_case">
                                                                        <p className="water_case_text">Water Bill</p>
                                                                    </div>
                                                                </div>

                                                                <div className="amount_transact">
                                                                    <div className="amount_case">
                                                                        <div className="case_amount">
                                                                            <p className="amount_case_text">-</p>
                                                                            <p className="amount_case_text2">₦ 70,000</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div className="status_transact">
                                                                    <div className="status_case">
                                                                        <div className="case_status">
                                                                            <p className="status_case_text">Successful</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div className="transact_case">  
                                                                <div className="table_case">
                                                                    <div className="case_table">
                                                                        <p className="table_case_text">20th June 22</p>
                                                                    </div>

                                                                </div>

                                                                <div className="beverly_transact">
                                                                    <img className="transact_img" src={process.env.PUBLIC_URL+"Ellipse 13.png"} alt="ellipse ill" />
                                                                        <div className="beverly_case">
                                                                            <p className="beverly_case_text">Beverly Hills</p>
                                                                            <p className="beverly_case_text2">Lagos, Nigeria</p>
                                                                        </div>
                                                                </div>
                                                                <div className="josh_transact">
                                                                     <img className="transact_img2" src={process.env.PUBLIC_URL+"Ellipse 14.png"} alt="ellipse ill png" />
                                                                        <div className="josh_case">
                                                                            <p className="josh_case_text">Josh Andrew</p>
                                                                        </div>
                                                                </div>

                                                                <div className="water_transact">
                                                                    <div className="water_case">
                                                                        <p className="water_case_text">Water Bill</p>
                                                                    </div>
                                                                </div>

                                                                <div className="amount_transact">
                                                                    <div className="amount_case">
                                                                        <div className="case_amount">
                                                                            <p className="amount_case_text">-</p>
                                                                            <p className="amount_case_text2">₦ 70,000</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div className="status_transact">
                                                                    <div className="status_case">
                                                                        <div className="case_status2">
                                                                            <p className="status_case_text2">Pending</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div className="transact_case">  
                                                                <div className="table_case">
                                                                    <div className="case_table">
                                                                        <p className="table_case_text">20th June 22</p>
                                                                    </div>

                                                                </div>

                                                                <div className="beverly_transact">
                                                                    <img className="transact_img" src={process.env.PUBLIC_URL+"Ellipse 13.png"} alt="ellipse ill" />
                                                                        <div className="beverly_case">
                                                                            <p className="beverly_case_text">Beverly Hills</p>
                                                                            <p className="beverly_case_text2">Lagos, Nigeria</p>
                                                                        </div>
                                                                </div>
                                                                <div className="josh_transact">
                                                                     <img className="transact_img2" src={process.env.PUBLIC_URL+"Ellipse 14.png"} alt="ellipse ill png" />
                                                                        <div className="josh_case">
                                                                            <p className="josh_case_text">Josh Andrew</p>
                                                                        </div>
                                                                </div>

                                                                <div className="water_transact">
                                                                    <div className="water_case">
                                                                        <p className="water_case_text">Water Bill</p>
                                                                    </div>
                                                                </div>

                                                                <div className="amount_transact">
                                                                    <div className="amount_case">
                                                                        <div className="case_amount">
                                                                            <p className="amount_case_text">-</p>
                                                                            <p className="amount_case_text2">₦ 70,000</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div className="status_transact">
                                                                    <div className="status_case">
                                                                        <div className="case_status">
                                                                            <p className="status_case_text">Successful</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>

                                                        </div>
                                                    <a href={process.env.PUBLIC_URL+"utility"} className="homelandland_load_btn"><p className="homelandland_load_btn_text">Load more</p></a>
                                            </div>
                                   
                                   </div>

                                   
                        </div>

                            
                </div>
                       
    );


};

export default Homelandlord;