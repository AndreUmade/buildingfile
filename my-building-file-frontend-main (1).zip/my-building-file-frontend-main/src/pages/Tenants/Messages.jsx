import React from "react";
import "./messages.css";

const Messages = () => {
    return (

        <div className="container">
            <div className="top_nav">
                    
            <nav className="pleasant_main">
                <a className="main_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                    <div className="sidebar">
                        <div className="sidebar_list">
                            <div className="sidebar_item1">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                            </div>
                            <div className="sidebar_item2" >
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties png"/></a>
                            </div>
                            <div className="sidebar_item3">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                            </div>
                            <div className="sidebar_item4">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                            </div>
                            <div className="sidebar_item5">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages-active.svg"} alt="message png"/></a>
                            </div>
                            <div className="sidebar_item6">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                            </div>
                            <div className="sidebar_item7">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                            </div>
                            
                        </div>
                            <div className="sidebar_logout">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+ "login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                            </div>
                            

                    </div>
            </nav>

            

            <div className="Messages_content">
                <div className="message_wrapper">
                    <h3 className="script_text">Messages</h3>
                    <p className="script_open">You have  <a className="link_blue" >2 new messages</a></p>
                    <div className="script_search">
                            <img className="property_search_img" src={process.env.PUBLIC_URL+"search scope.svg"} alt="scope png"/>
                                <input type="text" className="property_search_input" placeholder="Search property" />
                            </div>
                        <div className="fill_line"></div>

                        <div className="ghost_fill">
                        <p className="ghost_text">All Messages</p>
                        <a className="ghost_img" href=""><img src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/></a>
                        </div>

                    <div className="message_case">
                        <div className="message_case_wrapper">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                                <div className="message_time_amount">
                                    <p className="message_time_text2">2</p>
                                </div>
                            </div>
                        </div>

                        <div className="message_case_wrapper2">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                                <div className="message_time_amount">
                                    <p className="message_time_text2">2</p>
                                </div>
                            </div>
                        </div>

                        <div className="message_case_wrapper3">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                                <img className="message_ticks" src={process.env.PUBLIC_URL+"two-ticks.svg"} alt="two-ticks png"/>
                            </div>
                        </div>

                        <div className="message_case_wrapper4">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                                <img className="message_ticks" src={process.env.PUBLIC_URL+"one-tick.svg"} alt="two-ticks png"/>
                            </div>
                        </div>

                        <div className="message_case_wrapper5">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>
                

                    <div className="tenant_status">
                            <div className="tenant_status_case">
                                        <a href="tenant_status_case_img"><img className="" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="tenant_status_card">
                                        <h6 className="tenant_status_text">Mark Tony</h6>
                                        <p className="tenant_status_text2">Last seen 1hr ago</p>
                                    </div>
                            </div>
                            <a href="tel:0818-371-9660"><img className="tenant_status_img" src={process.env.PUBLIC_URL+"phone.svg"} alt="Ellipse-png"/></a>
                    </div>

                    <div className="chat_wrapper">
                        <div className="chat_menu_wrapper">
                            <img className="chat_menu_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="arrow-down png"/>
                            <p className="chat_menu_text">3 days ago</p>
                            <div className="chat_bar">
                                <p className="chat_bar_text">Hey Anthony, Do you like the property?</p>
                                <span className="chat_bar_text2">👍</span>
                            </div>
                           

                           <div class="message_dropdown_wrapper">
                                <input id="toggler2" type="checkbox"/>
                                <label for="toggler2">
                                <img className="chat_dropdown" src={process.env.PUBLIC_URL+"codicon.svg"} alt="vector png"/>
                                </label>
                                <div className="dropdown">
                                    <a className="dropdown_style3" href="">Delete message</a>
                                    <a className="dropdown_style4" href="">React to message</a>
                                    <a className="dropdown_style5" href="">Copy message</a>
                                </div>
                            </div>
                        </div>

                        <div className="chat_menu_wrapper2">
                            <img className="chat_dropdown2" src={process.env.PUBLIC_URL+"codicon.svg"} alt="vector png"/>
                            <p className="chat_menu_text2">3 days ago</p>
                            <div className="chat_bar2">
                                <p className="chat_bar_text3">Good afternoon sir, Hope you’re good. Yes, I checked out the property and I like it</p>
                            </div>
                        </div>

                        <div className="chat_menu_wrapper3">
                            <img className="chat_menu_img2" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="chat_menu_text3">3 days ago</p>
                            <div className="chat_bar3">
                                <p className="chat_bar_text4">Hey Anthony, Do you like the property?</p>
                            </div>
                            <div className="chat_property_select">
                                <img className="chat_property_select_img" src={process.env.PUBLIC_URL+"image7.svg"} alt="chat_property img png"/>
                                <img className="chat_property_select_img2" src={process.env.PUBLIC_URL+"image8.svg"} alt="chat_property img2 png"/>
                                    <div className="chat_property_case">
                                    <p className="chat_property_select_text">3</p>

                                    </div>
                            </div>
                            <a href=""><img className="chat_menu_img3" src={process.env.PUBLIC_URL+"ph_smiley-light.svg"} alt="ph_smiley-light png"/></a>
                        </div>

                        <div className="chat_menu_wrapper4">
                            <img className="chat_menu_img4" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="arrow-down png"/>
                                <p className="chat_menu_text4">3 days ago</p>
                                <div className="chat_bar4">
                                    <p className="chat_bar_text5">I think you would</p>
                            </div>
                            <img className="chat_dropdown3" src={process.env.PUBLIC_URL+"codicon.svg"} alt="vector png"/>
                                
                        </div>

                        <div className="chat_menu_wrapper5">
                            <img className="chat_dropdown4" src={process.env.PUBLIC_URL+"codicon.svg"} alt="vector png"/>
                            <p className="chat_menu_text5">2 days ago</p>
                            <div className="chat_bar5">
                                <p className="chat_bar_text6">Awesome. They all look cool, I’ll check them about soon</p>
                            </div>
                        </div>

                        <div className="chat_msg_input">
                            <input type="text" name="message" id="messages_input" className="message" placeholder="Write your Message"></input>

                                    
                                <a href="" ><img className="chat_input_img"  src={process.env.PUBLIC_URL+"ph_smiley-fill.svg"} alt="emoji-fll png"/></a>
                                <a href=""><img className="chat_input_img2"  src={process.env.PUBLIC_URL+"attach-file.svg"} alt="attach-file png"/></a>
                        </div>
                                <a href="" type="submit"><img className="chat_wrapper_img" src={process.env.PUBLIC_URL+"send-msg.svg"} alt="send-msg png"/></a>
                    </div>
                
                
                

            </div>
        </div>

    </div>
    )
};

export default Messages;