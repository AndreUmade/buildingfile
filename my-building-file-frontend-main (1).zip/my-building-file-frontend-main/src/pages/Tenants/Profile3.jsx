import React from "react";
import "./profile3.css";


const Profile3 = () => {
    return (

        <div className="pleasant">
            <div className="top_nav">
                    
            <nav className="pleasant_main">
                <a className="main_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                    <div className="sidebar">
                        <div className="sidebar_list">
                                <div className="sidebar_item1">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                                </div>
                                <div className="sidebar_item2" >
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Properties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties png"/></a>
                                </div>
                                <div className="sidebar_item3">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                                </div>
                                <div className="sidebar_item4">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                                </div>
                                <div className="sidebar_item5">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                                </div>
                                <div className="sidebar_item6">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                                </div>
                                <div className="sidebar_item7">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                                </div>
                                
                            </div>
                                <div className="sidebar_logout">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"LoginPage"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                                </div>
                            

                    </div>
            </nav>

            

            <div className="Messages_content">

                <div className="profile_content_wrapper">
                    <h3 className="profile_header_text">Profile</h3>
                    <div className="profile_header_line"></div>
                        <div className="profile_content_wrapper1">
                        <a href={process.env.PUBLIC_URL+"profile"}><div className="profile_content_case6">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"personal-inactive.svg"} alt="referral png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Personal Information</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div></a>

                            <a href={process.env.PUBLIC_URL+"profile2"}><div className="profile_content_case7">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"padlock.svg"} alt="secure png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Security</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div></a>

                            <div className="profile_content_case8">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"Subscription-active.svg"} alt="subscribe png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Subscriptions</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>

                
                <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>



                <div className="sub_field_wrapper">
                    <h4 className="sub_field_text">Subscriptions</h4>
                        <div className="sub_field_case">
                            <div className="sub_field_frame">
                                <div className="sub_field_input">
                                    <div className="sub_field_content">
                                        <p className="sub_field_text2">Property Plans</p>
                                        <div className="sub_card_wrapper">
                                                <div className="sub_card_content">
                                                    <img className="sub_card_img" src={process.env.PUBLIC_URL+"blue-tick.svg"} alt="selected png"/>
                                                        <div className="sub_card_case">
                                                            <p className="sub_card_text">Monthly</p>
                                                            <p className="sub_card_text2">21 days Left</p>
                                                        </div>
                                                        <p className="sub_card_text3">₦ 20,000<small className="sub_card_text4">/mo</small></p>
                                                        <a className="sub_card_btn" href=""><h6 className="sub_card_btn_text">Cancel Subscription</h6></a>
                                                </div>
                                                <div className="sub_card_content1">
                                                            <div className="sub_yearly_card">
                                                                <p className="sub_yearly_text">Yearly</p>
                                                                <p className="sub_yearly_text1">241 days Left</p>
                                                            </div>
                                                            <p className="sub_yearly_text2">₦ 80,000<small className="sub_yearly_text3">/yr</small></p>
                                                            <a className="sub_yearly_btn" href=""><h6 className="sub_yearly_btn_text">Upgrade</h6></a>
                                                </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="sub_card_line"></div>

                                <div className="sub_full_wrapper">
                                    <p className="sub_full_text">Full package Plan</p>
                                        <div className="sub_full_content">
                                            <img className="sub_full_img" src={process.env.PUBLIC_URL+"blue-tick.svg"} alt="selected png"/>
                                                <div className="sub_full_case">
                                                    <p className="sub_full_text">Yearly</p>
                                                    <p className="sub_full_text2">239 days Left</p>
                                                </div>
                                                <p className="sub_full_text3">₦ 20,000<small className="sub_full_text4">/yr</small></p>
                                                <a className="sub_full_btn" href=""><h6 className="sub_full_btn_text">Cancel Subscription</h6></a>
                                    
                                        </div>
                                </div>

                                <div className="sub_card_line1"></div>

                                <div className="sub_enable_wrapper">
                                    <div className="sub_enable_content">
                                        <p className="sub_enable_text">Enable auto-renew</p>
                                        <h6 className="sub_enable_text1">When this option is turned on, your subscription plan(s) will renew once the current plan expires.</h6>
                                    </div>
                                    <div className="sub_enable_switch_wrapper">
                                                    <label className="switch">
                                                    <input type="checkbox" />
                                                    <span className="slider round"></span>
                                                    </label>
                                    </div>
                                </div>
                                
                                <div className="sub_enable_line"></div>

                            </div>

                            <a href="" className="sub_enable_btn"><h6 className="sub_enable_btn_text">Save Changes</h6></a>
                        </div>
                </div>
                
            </div>
    </div>
</div>

    
)
};

export default Profile3;