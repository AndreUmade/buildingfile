import React from "react";
import "./properties4.css";


const Properties4 = () => {

    return (

        <div className="prop_container">

            <nav className="prop_content_case">
                <a className="main_logo" ><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                    <div className="sidebar">
                        <div className="sidebar_list">
                            <div className="sidebar_item1">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                            </div>
                            <div className="sidebar_item2" >
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties-active.svg"} alt="properties png"/></a>
                            </div>
                            <div className="sidebar_item3">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                            </div>
                            <div className="sidebar_item4">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                            </div>
                            <div className="sidebar_item5">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                            </div>
                            <div className="sidebar_item6">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                            </div>
                            <div className="sidebar_item7">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                            </div>
                            
                        </div>
                            
                        <div className="sidebar_logout">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+ "login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                        </div>
                            

                    </div>
                </nav>
                
            <div className="main_content">
                <div className="content_second">
                    <a className="back_wrapper">
                        <img className="back_img" src={process.env.PUBLIC_URL+"arrow-left.svg"} alt="referral png"/>
                        <h6 className="back_img_text">Back to Properties</h6>
                    </a>
                    <h3 className="content_text">Edit Property</h3>

                    <div className="content_frame_wrapper">
                        <div className="content_frame4">
                            <div className="content_frame_case">
                                <div className="content_frame_prop">
                                    <img className="content_frame_img" src={process.env.PUBLIC_URL+"prop details1.svg"} alt="details png"/>
                                </div>

                                <div className="content_frame_text_wrapper">
                                    <p className="content_frame_text">Property Details</p>
                                    <p className="content_frame_text1">Details and address information, etc</p>
                                </div>
                            </div>
                        </div>

                        <div className="content_frame1">
                            <div className="content_frame_case">
                                <div className="content_frame_prop">
                                    <img className="content_frame_img" src={process.env.PUBLIC_URL+"prop room.svg"} alt="details png"/>
                                </div>

                                <div className="content_frame_text_wrapper">
                                    <p className="content_frame_text">Rooms  </p>
                                    <p className="content_frame_text1">Units for each type of rooms</p>
                                </div>
                            </div>
                        </div>

                        <div className="content_frame2">
                            <div className="content_frame_case">
                                <div className="content_frame_prop">
                                    <img className="content_frame_img" src={process.env.PUBLIC_URL+"prop picture.svg"} alt="details png"/>
                                </div>

                                <div className="content_frame_text_wrapper">
                                    <p className="content_frame_text">Picture Upload</p>
                                    <p className="content_frame_text1">Manage pictures to display</p>
                                </div>
                            </div>
                        </div>

                        <div className="content_frame5">
                            <div className="content_frame_case">
                                <div className="content_frame_prop">
                                    <img className="content_frame_img" src={process.env.PUBLIC_URL+"prop tenant1.svg"} alt="details png"/>
                                </div>

                                <div className="content_frame_text_wrapper">
                                    <p className="content_frame_text">Tenants</p>
                                    <p className="content_frame_text1">Manage tenants living here</p>
                                </div>
                            </div>
                        </div>

                        

                    </div>
                </div>

                <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                    <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                <div className="property_delete_wrapper">
                    <div className="proprty_add_section">
                        <h4 className="propety_adddel_text">Tenants</h4>
                        <a className="property_add1_button" href="">
                            <img className="property_add1_button_img " src={process.env.PUBLIC_URL+"add.svg"} alt="add png"/>
                            <p className="property_add1_button_text">Add tenant</p>
                        </a>
                    </div>
                    
                    <div className="property_delete_section">
                        <div className="property_add_delete_case">
                            <div className="property_delete_frame">
                                <img className="property_delete_frame_img" src={process.env.PUBLIC_URL+"delete.svg"} alt="add png"/>
                                <p className="property_delete_frame_text">due on 6th Oct</p>
                                <img className="property_delete_frame_img1" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="add png"/>
                                <div className="property_delete_frame_sub">
                                    <p className="property_delete_sub_text">Andrew Tate</p>
                                    <p className="property_delete_sub_text1">andrewtate@gmail.com</p>
                                </div>
                            </div>

                            <div className="property_delete_frame1">
                                <img className="property_delete_frame_img" src={process.env.PUBLIC_URL+"delete.svg"} alt="add png"/>
                                <p className="property_delete_frame_text1">Overdue since 6th Mar</p>
                                <img className="property_delete_frame_img1" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="add png"/>
                                <div className="property_delete_frame_sub ">
                                    <p className="property_delete_sub1_text">Keanu Reeves</p>
                                    <p className="property_delete_sub_text1">andrewtate@gmail.com</p>
                                </div>
                            </div>

                            <div className="property_delete_frame2">
                                <img className="property_delete_frame_img" src={process.env.PUBLIC_URL+"delete.svg"} alt="add png"/>
                                <p className="property_delete_frame_text">due on 6th Oct</p>
                                <img className="property_delete_frame_img1" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="add png"/>
                                <div className="property_delete_frame_sub ">
                                    <p className="property_delete_sub_text">Tom Halland</p>
                                    <p className="property_delete_sub_text1">andrewtate@gmail.com</p>
                                </div>
                            </div>
                        </div>

                        
                    </div>

                    <a className="property_delete_frame_button" href="">
                        <h6 className="property_delete_frame_button_text">Save Changes</h6>
                    </a>

                </div>
            </div>

        </div>
    )
}; 

export default Properties4;   

 

