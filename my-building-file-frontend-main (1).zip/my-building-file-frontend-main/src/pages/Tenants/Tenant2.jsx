import React from "react";
import "./tenant2.css";

const Tenant2 = () => {
    return (
        <div className="tenant_main_case">
            <div className="top_nav">

                <div className="landlord_main">
                    <a className="main_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                        <div className="sidebar">
                            <div className="sidebar_list">
                                <div className="sidebar_item1">
                                        <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                                    </div>
                                    <div className="sidebar_item2" >
                                        <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties png"/></a>
                                    </div>
                                    <div className="sidebar_item3">
                                        <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                                    </div>
                                    <div className="sidebar_item4">
                                        <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                                    </div>
                                    <div className="sidebar_item5">
                                        <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                                    </div>
                                    <div className="sidebar_item6">
                                        <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                                    </div>
                                    <div className="sidebar_item7">
                                        <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                                    </div>
                                    
                            </div>
                                    <div className="sidebar_logout">
                                        <a className="sidebar_tool" href={process.env.PUBLIC_URL+"login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                                    </div>
                                

                        </div>
                </div>
            </div>

            <div className="tenant_main_content">
                <a className="tenant2_back_wrapper" href={process.env.PUBLIC_URL+"tenant"}>
                    <img  className="tenant2_back_img" src={process.env.PUBLIC_URL+"arrow-left.svg"} alt="arrow-left png"/>
                    <h6 className="tenant2_back_text">Back to Tenants</h6>
                </a>

                <a className="tenant2_payment_btn" href="">
                    <img className="tenant2_payment_img" src={process.env.PUBLIC_URL+"payment update.svg"} alt=" paymentpng"/>
                    <h6 className="tenant2_payment_text">Update Payments</h6>
                </a>

                <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                <div className="tenant2_owned_wrapper">
                    <div className="tenant2_all_owned_wrapper">
                        <div className="tenant2_owned_content">
                            <h6 className="tenant2_owned_text">PROPERTIES OWNED</h6>
                            <div className="tenant2_scroll_wrapper">
                                <a className="tenant2_scroll_slide" href={process.env.PUBLIC_URL+""}><img  src={process.env.PUBLIC_URL+"slider left.svg"} alt=" png"/></a>
                                <a className="tenant2_scroll_slide1" href={process.env.PUBLIC_URL+""}><img  src={process.env.PUBLIC_URL+"slider right.svg"} alt=" png"/></a>
                            </div>

                            <div className="tenant2_owned_card">
                                <div className="tenant2_owned_propcard">
                                    <img className="tenant2_owned_propcard_img" src={process.env.PUBLIC_URL+"tenant2 rectangle.svg"} alt=" png"/>
                                    <div className="tenant2_owned_textcard">
                                        <div className="tenant2_owned_headertext_wrapper">
                                            <h5 className="tenant2_owned_headertext">Queen’s Park House</h5>
                                            <p className="tenant2_owned_headertext1">12 Avenue, Baptist Estate, Surulere, Lagos</p>
                                        </div>
                                        <div className="tenant2_owned_textcard_line"></div>

                                        <div className="tenant2_owned_features">
                                            <div className="tenant2_owned_features_frame">
                                                <img className="tenant2_owned_features_img" src={process.env.PUBLIC_URL+"bathroom active.svg"} alt="bathroom png"/>
                                                <p className="tenant2_owned_features_text">2 Bathrooms</p>
                                            </div>

                                            <div className="tenant2_owned_features_frame1">
                                                <img className="tenant2_owned_features_img" src={process.env.PUBLIC_URL+"bedroom active.svg"} alt="bedroom png"/>
                                                <p className="tenant2_owned_features_text">2 Beds</p>
                                            </div>

                                            <div className="tenant2_owned_features_frame2">
                                                <img className="tenant2_owned_features_img" src={process.env.PUBLIC_URL+"apartment.svg"} alt="apartment png"/>
                                                <p className="tenant2_owned_features_text">620 sqm</p>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div className="tenant2_owned_propcard">
                                    <img className="tenant2_owned_propcard_img" src={process.env.PUBLIC_URL+"tenant2 rectangle.svg"} alt=" png"/>
                                    <div className="tenant2_owned_textcard">
                                        <div className="tenant2_owned_headertext_wrapper">
                                            <h5 className="tenant2_owned_headertext">Queen’s Park House</h5>
                                            <p className="tenant2_owned_headertext1">12 Avenue, Baptist Estate, Surulere, Lagos</p>
                                        </div>
                                        <div className="tenant2_owned_textcard_line"></div>

                                        <div className="tenant2_owned_features">
                                            <div className="tenant2_owned_features_frame">
                                                <img className="tenant2_owned_features_img" src={process.env.PUBLIC_URL+""} alt=" png"/>
                                                <p className="tenant2_owned_features_text">2 Bathrooms</p>
                                            </div>

                                            <div className="tenant2_owned_features_frame">
                                                <img className="" src={process.env.PUBLIC_URL+""} alt=" png"/>
                                                <p className="">2 Beds</p>
                                            </div>

                                            <div className="tenant2_owned_features_frame">
                                                <img className="" src={process.env.PUBLIC_URL+""} alt=" png"/>
                                                <p className="">620 sqm</p>
                                            </div>

                                        </div>
                                    </div>
                                </div>


                            </div>

                            
                            
                        </div>

                        <div className="tenant2_transact_owned">
                            <h6 className="tenant2_transact_owned_text">TRANSACTION</h6>
                            <div className="tenant2_transact_owned_header">
                                <div className="tenant2_transact_owned_content">
                                    <div className="tenant2_transact_nextpay">
                                        <img className="tenant2_transact_nextpay_img" src={process.env.PUBLIC_URL+"calendar.svg"} alt=" png"/>
                                        <p className="tenant2_transact_nextpay_text">12th Oct, 2022</p>
                                    </div>

                                    <div className="tenant2_transact_nextpay1">
                                        <img className="tenant2_transact_nextpay_img1" src={process.env.PUBLIC_URL+"money-time.svg"} alt=" png"/>
                                        <p className="tenant2_transact_nextpay_text1">₦ 1,200,000</p>
                                    </div>

                                    <div className="tenant2_transact_nextpay3">   
                                        <div className="tenant2_transact_nextpay3_case">
                                            <img className="tenant2_transact_nextpay_img2" src={process.env.PUBLIC_URL+"timer.svg"} alt=" png"/>
                                            <p className="tenant2_transact_nextpay_text2">6 months,5days</p>
                                        </div>
                                    </div>

                                    <img className="tenant2_transact_nextpay4" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt=" png"/>

                                </div>

                                <div className="tenant2_transact_owned_content">
                                    <div className="tenant2_transact_nextpay">
                                        <img className="tenant2_transact_nextpay_img" src={process.env.PUBLIC_URL+"calendar.svg"} alt=" png"/>
                                        <p className="tenant2_transact_nextpay_text">12th Oct, 2022</p>
                                    </div>

                                    <div className="tenant2_transact_nextpay1">
                                        <img className="tenant2_transact_nextpay_img1" src={process.env.PUBLIC_URL+"money-time.svg"} alt=" png"/>
                                        <p className="tenant2_transact_nextpay_text1">₦ 1,200,000</p>
                                    </div>

                                    <div className="tenant2_transact_nextpay3">   
                                        <div className="tenant2_transact_nextpay3_case">
                                            <img className="tenant2_transact_nextpay_img2" src={process.env.PUBLIC_URL+"timer.svg"} alt=" png"/>
                                            <p className="tenant2_transact_nextpay_text2">6 months,5days</p>
                                        </div>
                                    </div>

                                    <img className="tenant2_transact_nextpay4" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt=" png"/>

                                </div>                                
                            </div>
                        </div>

                        <div className="tenant2_guarantor_wrapper">
                            <h5 className="tenant2_guarantor_text">GUARANTORS</h5>
                            <div className="tenant2_guarantor_content">
                                <div className="tenant2_guarantor_header">
                                    <h6 className="tenant2_guarantor_text1">Personal Details</h6>

                                    <div className="tenant2_guarantor_line"></div>
                                    <div className="tenant2_guarantor_id_case">
                                        <div className="tenant2_guarantor_name">
                                            <p className="tenant2_guarantor_name_text">Name</p>
                                            <h6 className="tenant2_guarantor_name_text1">Hendrix James</h6>
                                        </div>

                                        <div className="tenant2_guarantor_number">
                                            <p className="tenant2_guarantor_number_text">Phone Number</p>
                                            <h6 className="tenant2_guarantor_number_text1">07067041603</h6>
                                        </div>

                                        <div className="tenant2_guarantor_email">
                                            <p className="tenant2_guarantor_email_text">Email</p>
                                            <h6 className="tenant2_guarantor_email_text1">hendrixjames@gmail.com</h6>
                                        </div>
                                    </div>
                                    
                                    <h6 className="tenant2_guarantor_kyc">KYC Info</h6>
                                    <div className="tenant2_guarantor_line1"></div>

                                    
                                    <h6 className="tenant2_guarantor_licence">Driver’s Licence</h6>

                                    <a className="tenant2_guarantor_btn" href="">
                                        <p className="tenant2_guarantor_btn_text">View</p>
                                    </a>
                                </div>

                                <div className="tenant2_guarantor_header1">
                                    <h6 className="tenant2_guarantor_text1">Personal Details</h6>

                                    <div className="tenant2_guarantor_line"></div>
                                    <div className="tenant2_guarantor_id_case">
                                        <div className="tenant2_guarantor_name">
                                            <p className="tenant2_guarantor_name_text">Name</p>
                                            <h6 className="tenant2_guarantor_name_text1">Hendrix James</h6>
                                        </div>

                                        <div className="tenant2_guarantor_number">
                                            <p className="tenant2_guarantor_number_text">Phone Number</p>
                                            <h6 className="tenant2_guarantor_number_text1">07067041603</h6>
                                        </div>

                                        <div className="tenant2_guarantor_email">
                                            <p className="tenant2_guarantor_email_text">Email</p>
                                            <h6 className="tenant2_guarantor_email_text1">hendrixjames@gmail.com</h6>
                                        </div>
                                    </div>
                                    
                                    <h6 className="tenant2_guarantor_kyc">KYC Info</h6>
                                    <div className="tenant2_guarantor_line1"></div>

                                    
                                    <h6 className="tenant2_guarantor_licence">Driver’s Licence</h6>

                                    <a className="tenant2_guarantor_btn" href="">
                                        <p className="tenant2_guarantor_btn_text">View</p>
                                    </a>
                                </div>


                            </div>
                        </div>
                        
                        

                    </div>
                </div>

                <div className="tenant2_contact_card">
                            <img className="tenant2_contact_card_img" src={process.env.PUBLIC_URL+"tenant contactimg.svg"} alt=" png"/>
                            <div className="tenant2_contact_card_content">
                                <div className="tenant2_contact_card_line"></div>
                                <div className="tenant2_contact_name">
                                    <p className="tenant2_contact_name_text">Name</p>
                                    <p className="tenant2_contact_name_text1">Andrew Tate</p>
                                </div>
                                <div className="tenant2_contact_card_line1"></div>

                                <div className="tenant2_contact_phone">
                                    <p className="tenant2_contact_phone_text">Phone Number</p>
                                    <p className="tenant2_contact_phone_text1">09033057246</p>
                                </div>
                                <div className="tenant2_contact_line2"></div>

                                <div className="tenant2_contact_email">
                                    <p className="tenant2_contact_email_text">Email</p>
                                    <p className="tenant2_contact_email_text1">andrewtate@gmail.com</p>
                                </div>
                                <div className="tenant2_contact_line3"></div>

                                <div className="tenant2_contact_date">
                                    <p className="tenant2_contact_date_text">Date of Birth</p>
                                    <p className="tenant2_contact_date_text1">19-24-1998</p>
                                </div>
                                <div className="tenant2_contact_line4"></div>

                                <div className="tenant2_contact_address">
                                    <p className="tenant2_contact_address_text">Address</p>
                                    <p className="tenant2_contact_address_text1">12 Avenue, TopG Estate, Isolo, Lagos</p>
                                </div>
                                <div className="tenant2_contact_line5"></div>
                            </div>

                            <a href={process.env.PUBLIC_URL+"messages2"} className="tenant2_contact_btn">
                                <p className="tenant2_contact_btn_text">Messages</p>
                            </a>
                </div>

            </div>
    </div>


        
    );
};

export default Tenant2;