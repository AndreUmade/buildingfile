import React from "react";
import "./properties.css";
import { useState } from 'react';
import { Modal } from "react-bootstrap";

const Properties = () => {

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  

    return (

        <div className="container">


     <Modal className="modal_main" show={show} onHide={handleClose}>
       
       <div className="modal_case">
           <div className="modal_top_line"></div>
           <img className="modal_img" src={process.env.PUBLIC_URL+"close-round.svg"} onClick={handleClose}/>
                       
               <div className="modal1_add_property">
                   <div className="modal1_personal">
                       <div className="modal1_personal_case">
                           <p className="modal1_personal_text">1</p>
                       </div>
                       <p className="modal1_personal_text1">Personal Details</p>
                   </div>

                   <div className="modal1_rooms">
                       <div className="modal1_rooms_case">
                           <p className="modal1_rooms_text">2</p>
                       </div>
                       <p className="modal1_rooms_text1">Rooms</p>
                   </div>

                   <div className="modal1_picture">
                       <div className="modal1_picture_case">
                           <p className="modal1_picture_text">3</p>
                       </div>
                       <p className="modal1_picture_text1">Pictures Upload</p>
                   </div>
                   <div className="modal1_line1"></div>
                   <div className="modal1_line2"></div>
               </div>

                   <div className="modal1_line"></div>


                   <div className="modal1_property_detail">
                       <h4 className="modal1_prop_detail_text">Property Details</h4>
                       <p className="modal1_prop_detail_text1">Enter the details and address information of the property </p>
                   </div>

           <div className="modal1_fields">
               <div className="modal1_field_frame">
                   <div className="modal1_field_content">
                       <label for="fname" className="modal1_field_tag">Name of Property</label>
                       <input className="modal1_field_input" type="text" id="fname" name="fname" placeholder="Beverly House" />
                   </div>

                   <div className="modal1_field_content1">
                       <label for="fname" className="modal1_field_tag1">Size<p className="modal1_field_tag1_text">(in sqm)</p></label>
                       <input className="modal1_field_input1" type="number" id="fname" name="fname" placeholder="62" />
                   </div>
               </div>

               <div className="modal1_field_frame1">
                   <div className="modal1_field_content2">
                       <label for="fname" className="modal1_field_tag2">Property Description</label>
                       <textarea className="modal1_field_input2" type="text" id="fname" name="fname" placeholder="Enter description here..."/>
                   </div>
               </div>

               <div className="modal1_field_frame2">
                   <div className="modal1_field_content3">
                       <label for="fname" className="modal1_field_tag3">Street Address</label>
                       <input className="modal1_field_input3" type="text" id="fname" name="fname" placeholder="Beverly House" />
                   </div>
               </div>

               <div className="modal1_field_frame3">
                   <div className="modal1_field_content4">
                       <label for="fname" className="modal1_field_tag4">City</label>
                       <input className="modal1_field_input4" type="text" id="fname" name="fname" placeholder="Beverly House" />
                   </div>

                   <div className="modal1_field_content5">
                       <label for="fname" className="modal1_field_tag5">State</label>
                       <input className="modal1_field_input5" type="text" id="fname" name="fname" placeholder="Beverly House" />
                   </div>
               </div>
           
           </div>

           <div className="modal1_btn_wrapper">
               <a data-dismiss="modal_main1" data-toggle="modal2_main1" href="#modal2" className="modal1_btn" >
                   <h6 className="modal1_btn_text">Proceed to Next Step</h6>
               </a>
           </div>
   </div>
</Modal>





            <nav className="homelandlord_main">
            <a className="main_logo" ><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                <div className="sidebar">
                    <div className="sidebar_list">
                        <div className="sidebar_item1">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                        </div>
                        <div className="sidebar_item2" >
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties-active.svg"} alt="properties png"/></a>
                        </div>
                        <div className="sidebar_item3">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                        </div>
                        <div className="sidebar_item4">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                        </div>
                        <div className="sidebar_item5">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                        </div>
                        <div className="sidebar_item6">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                        </div>
                        <div className="sidebar_item7">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                        </div>
                        
                    </div>
                        <div className="sidebar_logout">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+ "login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                        </div>
                        

                </div>
            </nav>
            <div className="content">

                            <h3 className="anderson_text">Properties</h3>
                            <p className="anderson_text2">You have listed a total of <a className="link_blue" >12 properties</a></p>

                            <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                    <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                            <a  className="build_btn" onClick={handleShow}>
                            <img className="build_img" src={process.env.PUBLIC_URL+"building.svg"} alt="building-png"/><h6 className="build_img_text">Add Properties</h6>
                            </a>

                            <div className="nested">
                                <div className="nested_case">


                                    <div className="nest1">
                                        <a href={process.env.PUBLIC_URL+"properties2"}><p className="nest_flow">All Properties</p></a>
                                    </div>
                                    <div className="nest2">
                                        <p className="nest_flow1">Occupied</p>
                                    </div>

                                    <div className="nest3">
                                        <p className="nest_flow2">Vacant</p>
                                    </div>

                                </div>
                            </div>


                            <div className="property_search">
                            <img className="property_search_img" src={process.env.PUBLIC_URL+"search scope.svg"} alt="scope png"/>
                                <input type="text" className="property_search_input" placeholder="Search Property" />
                            </div>


                        <div className="Sugar">
                            <div className="grid_case">
                                        <div className="card-img-wrapper">
                                            <img className="card_grid_img" src={process.env.PUBLIC_URL+"rectangle img.svg"} alt="naira-png"/>
                                        </div>
                                        <div className="grid-case_body">
                                                <div className="card_grid">
                                                    <img className="grid_card_img" src={process.env.PUBLIC_URL+"naira.svg"} alt="naira-png"/>
                                                    <h4 className="grid_naira_text">800,000<span className="grid_naira_text2">/year</span></h4>
                                                </div>
                                        
                                                <p className="card_grid_text2">12 Avenue, Baptist Estate, Surulere, Lagos</p>
                                                <h4 className="card_grid_text">Queen's Park</h4>
                                                <div className="linen"></div>
                                        </div>
                                    
                                    <div className="groupy">
                                        <img className="groupy_img1" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="naira-png"/>
                                        <img className="groupyimg2" src={process.env.PUBLIC_URL+"Ellipse 8.svg"} alt="naira-png"/>
                                        <img className="groupy_img3" src={process.env.PUBLIC_URL+"Ellipse 9.svg"} alt="naira-png"/>
                                            <div className="groupy_card">
                                                <p className="groupy_text">2</p>
                                            </div>

                                    </div>
                            </div>


                            <div className="grid_case">
                                        <div className="card-img-wrapper">
                                            <img className="card_grid_img" src={process.env.PUBLIC_URL+"rectangle img.svg"} alt="naira-png"/>
                                        </div>
                                        <div className="grid-case_body">
                                            <div className="card_grid">
                                                <img className="grid_card_img" src={process.env.PUBLIC_URL+"naira.svg"} alt="naira-png"/>
                                                <h4 className="grid_naira_text">800,000<span className="grid_naira_text2">/year</span></h4>
                                            </div>
                                   
                                            <p className="card_grid_text2">12 Avenue, Baptist Estate, Surulere, Lagos</p>
                                            <h4 className="card_grid_text">Queen's Park</h4>
                                            <div className="linen"></div>
                                        </div>
                                    
                                    <div className="groupy">
                                        <img className="groupy_img1" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="naira-png"/>
                                        <img className="groupyimg2" src={process.env.PUBLIC_URL+"Ellipse 8.svg"} alt="naira-png"/>
                                        <img className="groupy_img3" src={process.env.PUBLIC_URL+"Ellipse 9.svg"} alt="naira-png"/>
                                            <div className="groupy_card">
                                                <p className="groupy_text">2</p>
                                            </div>

                                    </div>
                            </div>
                            
                            <div className="grid_case">
                                        <div className="card-img-wrapper">
                                            <img className="card_grid_img" src={process.env.PUBLIC_URL+"rectangle img.svg"} alt="naira-png"/>
                                        </div>
                                        <div className="grid-case_body">
                                                <div className="card_grid">
                                                    <img className="grid_card_img" src={process.env.PUBLIC_URL+"naira.svg"} alt="naira-png"/>
                                                    <h4 className="grid_naira_text">800,000<span className="grid_naira_text2">/year</span></h4>
                                                </div>
                                   
                                                <p className="card_grid_text2">12 Avenue, Baptist Estate, Surulere, Lagos</p>
                                                <h4 className="card_grid_text">Queen's Park</h4>
                                                <div className="linen"></div>
                                        </div>
                                    
                                    <div className="groupy">
                                        <img className="groupy_img1" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="naira-png"/>
                                        <img className="groupyimg2" src={process.env.PUBLIC_URL+"Ellipse 8.svg"} alt="naira-png"/>
                                        <img className="groupy_img3" src={process.env.PUBLIC_URL+"Ellipse 9.svg"} alt="naira-png"/>
                                            <div className="groupy_card">
                                                <p className="groupy_text">2</p>
                                            </div>

                                    </div>
                            </div>

                        </div>
                            
                            
                </div>


        </div>
    )
}; 

export default Properties;   

 

