import React from "react";
import "./wallet.css";

const Wallet = () => {
    return (

        <div className="container">
            <div className="top_nav">
                    
            <nav className="pleasant_main">
                <a className="main_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                    <div className="sidebar">
                        <div className="sidebar_list">
                            <div className="sidebar_item1">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                            </div>
                            <div className="sidebar_item2" >
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties png"/></a>
                            </div>
                            <div className="sidebar_item3">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                            </div>
                            <div className="sidebar_item4">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet-active.svg"} alt="wallet png"/></a>
                            </div>
                            <div className="sidebar_item5">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                            </div>
                            <div className="sidebar_item6">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                            </div>
                            <div className="sidebar_item7">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                            </div>
                            
                        </div>
                            <div className="sidebar_logout">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+ "login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                            </div>
                            

                    </div>
            </nav>

            

            <div className="Messages_content">
                <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                <h3 className="utility_bill_text">Wallet</h3>
                <div className="wallet_cards">
                    <div className="wallet_nigeria">
                        <p className="wallet_available">Available Balance</p>
                        <img className="wallet_visible" src={process.env.PUBLIC_URL+"visibility2.svg"} alt="visible png"/>
                        <img className="wallet_visible1" src={process.env.PUBLIC_URL+"card group2.svg"} alt="group png"/>
                        <img className="wallet_visible4" src={process.env.PUBLIC_URL+"wallet-blur.svg"} alt="blur png"/>
                        <img className="wallet_visible2" src={process.env.PUBLIC_URL+"card group1.svg"} alt="group2 png"/>
                        <h3 className="wallet_available_text">₦ 500,000.55</h3>
                        <img className="wallet_visible3" src={process.env.PUBLIC_URL+"emojione_flag-for-nigeria.svg"} alt="flag png"/>
                        <div className="wallet_btn_wrapper">
                            <a href="">
                            <button className="wallet_btn" type="submit">
                                <img className="wallet_btn_img" src={process.env.PUBLIC_URL+"add.svg"} alt="add png"/>
                                <p className="wallet_btn_text">Add Money</p>
                            </button>
                            </a>
                            
                            <a href="">
                            <button className="wallet_withdraw_btn">
                                <img className="wallet_withdraw_img" src={process.env.PUBLIC_URL+"balance-arrow.svg"} alt="balance-arrow png"/>
                                <p className="wallet_withdraw_text">Withdraw Funds</p>
                            </button>
                            </a>
                        </div>
                    </div>
                    <div className="wallet_balance">

                            <h3 className="wallet_balance_account">2049456861</h3>
                            <p className="wallet_balance_bank">United Bank for Africa</p>
                            <img className="wallet_balance_img1" src={process.env.PUBLIC_URL+"Group 459.svg"} alt="group png"/>
                            <img className="wallet_balance_img2" src={process.env.PUBLIC_URL+"Group 458.svg"} alt="group png"/>

                            <a href="">
                            <button className="wallet_balance_btn" >
                                <img className="wallet_balance_img" src={process.env.PUBLIC_URL+"change-bank.svg"} alt="change bank.png"/>
                                <p className="wallet_balance_text">Change Bank</p>
                            </button>
                            </a>
                    </div>
                </div>

                <div className="wallet_history">
                        <h5 className="wallet_history_text">Transaction History</h5>
                    <div className="wallet_history_case">
                        <div className="wallet_history_table">
                            <div className="wallet_history_column">
                                <div className="wallet_history_header">
                                    <img className="wallet_history_img" src={process.env.PUBLIC_URL+"diagonal-up.svg"} alt="change bank.png"/>
                                        <div className="wallet_history_group">
                                            <p className="wallet_history_text1">Withdrawal</p>
                                            <p className="wallet_history_text2">20th June 23</p>
                                        </div>
                                </div>
                            </div>

                            <div className="wallet_history_amount">
                                <h6 className="wallet_history_amount_text">- ₦ 70,000</h6>
                            </div>
                            
                            <div className="wallet_history_success_wrapper">
                                <div className="wallet_history_success">
                                    <p className="wallet_history_success_text">Successful</p>
                                </div>
                            </div>
                        </div>

                        <div className="wallet_history_table1">
                            <div className="wallet_history_column">
                                <div className="wallet_history_header">
                                    <img className="wallet_history_img" src={process.env.PUBLIC_URL+"diagonal-down.svg"} alt="diagonal down.png"/>
                                        <div className="wallet_history_group">
                                            <p className="wallet_history_text1">Top Up</p>
                                            <p className="wallet_history_text2">20th June 23</p>
                                        </div>
                                </div>
                            </div>

                            <div className="wallet_history_amount">
                                <h6 className="wallet_history_amount_text">+ ₦8,920,000</h6>
                            </div>
                            
                            <div className="wallet_history_success_wrapper">
                                <div className="wallet_history_success">
                                    <p className="wallet_history_success_text">Successful</p>
                                </div>
                            </div>
                        </div>

                        <div className="wallet_history_table2">
                            <div className="wallet_history_column">
                                <div className="wallet_history_header">
                                    <img className="wallet_history_img" src={process.env.PUBLIC_URL+"diagonal-up.svg"} alt="diagonal down.png"/>
                                        <div className="wallet_history_group">
                                            <p className="wallet_history_text1">Withdrawal</p>
                                            <p className="wallet_history_text2">20th June 23</p>
                                        </div>
                                </div>
                            </div>

                            <div className="wallet_history_amount">
                                <h6 className="wallet_history_amount_text">₦120,000</h6>
                            </div>
                            
                            <div className="wallet_history_success_wrapper">
                                <div className="wallet_history_success2">
                                    <p className="wallet_history_success_text2">Failed</p>
                                </div>
                            </div>
                        </div>

                    </div>

                    

                </div>

                <img className="wallet_stats" src={process.env.PUBLIC_URL+"wallet-stats.svg"} alt="wallet-stats png"/>
                
            </div>

    </div>
</div>

    
    )
};

export default Wallet;