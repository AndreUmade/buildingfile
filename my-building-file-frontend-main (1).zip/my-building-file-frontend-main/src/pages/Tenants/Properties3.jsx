import React from "react";
import "./properties3.css";


const Properties3 = () => {

    return (

        <div className="prop_container">

            <nav className="prop_content_case">
                <a className="main_logo" ><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                    <div className="sidebar">
                        <div className="sidebar_list">
                            <div className="sidebar_item1">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                            </div>
                            <div className="sidebar_item2" >
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties-active.svg"} alt="properties png"/></a>
                            </div>
                            <div className="sidebar_item3">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                            </div>
                            <div className="sidebar_item4">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                            </div>
                            <div className="sidebar_item5">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                            </div>
                            <div className="sidebar_item6">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                            </div>
                            <div className="sidebar_item7">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                            </div>
                            
                        </div>
                            
                        <div className="sidebar_logout">
                            <a className="sidebar_tool" href={process.env.PUBLIC_URL+ "login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                        </div>
                            

                    </div>
                </nav>
                
            <div className="main_content">
                <div className="content_second">
                    <a className="back_wrapper">
                        <img className="back_img" src={process.env.PUBLIC_URL+"arrow-left.svg"} alt="referral png"/>
                        <h6 className="back_img_text">Back to Properties</h6>
                    </a>
                    <h3 className="content_text">Edit Property</h3>

                    <div className="content_frame_wrapper">
                        <div className="content_frame">
                            <div className="content_frame_case">
                                <div className="content_frame_prop">
                                    <img className="content_frame_img" src={process.env.PUBLIC_URL+"prop details.svg"} alt="details png"/>
                                </div>

                                <div className="content_frame_text_wrapper">
                                    <p className="content_frame_text">Property Details</p>
                                    <p className="content_frame_text1">Details and address information, etc</p>
                                </div>
                            </div>
                        </div>

                        <div className="content_frame1">
                            <div className="content_frame_case">
                                <div className="content_frame_prop">
                                    <img className="content_frame_img" src={process.env.PUBLIC_URL+"prop room.svg"} alt="details png"/>
                                </div>

                                <div className="content_frame_text_wrapper">
                                    <p className="content_frame_text">Rooms  </p>
                                    <p className="content_frame_text1">Units for each type of rooms</p>
                                </div>
                            </div>
                        </div>

                        <div className="content_frame2">
                            <div className="content_frame_case">
                                <div className="content_frame_prop">
                                    <img className="content_frame_img" src={process.env.PUBLIC_URL+"prop picture.svg"} alt="details png"/>
                                </div>

                                <div className="content_frame_text_wrapper">
                                    <p className="content_frame_text">Picture Upload</p>
                                    <p className="content_frame_text1">Manage pictures to display</p>
                                </div>
                            </div>
                        </div>

                        <div className="content_frame3">
                            <div className="content_frame_case">
                                <div className="content_frame_prop">
                                    <img className="content_frame_img" src={process.env.PUBLIC_URL+"prop tenant.svg"} alt="details png"/>
                                </div>

                                <div className="content_frame_text_wrapper">
                                    <p className="content_frame_text">Tenants</p>
                                    <p className="content_frame_text1">Manage tenants living here</p>
                                </div>
                            </div>
                        </div>

                        

                    </div>
                </div>

                <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                    <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>


                <div className="property_chat">
                    <h4 className="property_chat-text">Property details</h4>
                    <div className="property_details_field_wrapper">
                        <div className="property_details_field">
                            <div className="property_name_all">
                                <div className="property_name_input">
                                    <div className="property_name_main">
                                            <label for="fname" className="property_name_input_text">Name of Property</label>
                                            <input className="property_name_input_field" type="text" id="fname" name="fname" placeholder="Beverly House" />
                                    </div>
                                </div>

                                <div className="property_size_wrapper">
                                    <div className="property_size_field">
                                            <label for="numbers" className="property_size_input_text">Size<p className="property_size_input_text1">(in sqm)</p></label>
                                            <input className="property_size_input_field" type="number" id="fname" name="fname" placeholder="62" />
                                    </div>
                                </div>
                            </div>

                            <div className="property_descript_wrapper">
                                    <label for="text" className="property_descript_input_text">Property Description</label>
                                    <textarea className="property_descript_input_field" type="text" id="fname" name="fname" placeholder="Enter description here..."/>
                            </div>

                            <div className="property_status_wrapper">
                                <div className="property_status_content">
                                    <label for="property" className="property_status_input_text">Status</label>
                                    <select id="property" className="property_status_input_field" >
                                        <option value="">Vacant</option>
                                        <option value="woman">Occupied</option>
                                        <option value="woman">Reserved</option>
                                        <option value="another">Others</option>
                                    </select>
                                </div>
                            </div>

                            <div className="property_street_wrapper">
                                <div className="property_street_content">
                                    <label for="fname" className="property_street_input_text">Street Address</label>
                                    <input className="property_street_input_field" type="text" id="fname" name="fname" placeholder="No 23 Shell location" />
                                </div>
                            </div>

                            <div className="property_city_state">
                                <div className="property_city_wrapper">
                                    <label for="fname" className="property_city_input_text">City</label>
                                    <input className="property_city_input_field" type="text" id="fname" name="fname" placeholder="Port Harcourt" />
                                </div>

                                <div className="property_state_wrapper">
                                    <label for="property" className="property_state_input_text">Status</label>
                                        <select id="property" className="property_state_input_field" placeholder="Vacant">
                                            <option value="" className="property_state_input_field_main">select state</option>
                                            <option value="woman">Abia State</option>
                                            <option value="woman">Adamawa</option>
                                            <option value="another">Akwa Ibom</option>
                                            <option value="another">Delta</option>
                                            <option value="another">Lagos</option>
                                            <option value="another">Abuja</option>
                                        </select>
                                </div>
                            </div>

                        </div>

                        <a className="property_button">
                            <h6 className="property_button_text">Save Changes</h6>
                        </a>

                    </div>
                </div>
            </div>

        </div>
    )
}; 

export default Properties3;   

 

