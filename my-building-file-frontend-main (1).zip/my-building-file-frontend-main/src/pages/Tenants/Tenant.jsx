import React from "react";
import "./tenant.css";

const tenant = () => {
    return (
        <div className="container">
            

        <nav className="homelandlord_main">
            <a className="main_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                <div className="sidebar">
                    <div className="sidebar_list">
                        <div className="sidebar_item1">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                            </div>
                            <div className="sidebar_item2" >
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties png"/></a>
                            </div>
                            <div className="sidebar_item3">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant-active.svg"} alt="tenants png"/></a>
                            </div>
                            <div className="sidebar_item4">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                            </div>
                            <div className="sidebar_item5">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                            </div>
                            <div className="sidebar_item6">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                            </div>
                            <div className="sidebar_item7">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                            </div>
                            
                        </div>
                            <div className="sidebar_logout">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                            </div>
                        

                </div>
            </nav>
            <div className="content">

                            <h3 className="anderson_text">Tenants</h3>
                            <p className="anderson_text2">Tenants vacating at the end of the month are <p className="link_blue1">4</p></p>

                            <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                            <a href="" className="hendrix_btn" src=""><img className="hendrix_img2" src={process.env.PUBLIC_URL+"user-add.png"} alt="user_add-png"/><h6 className="hendrix_img_text">Add Tenants</h6></a>
                            
                            <p className="hendrix_flow_text">Showing 1-8 of 20 results</p>

                            <div className="pag">
                                <div className="pag_item">
                                <a className="pag_item_text" href=""><img  src={process.env.PUBLIC_URL+"leftarrow.svg"} alt="coded png"/></a>
                                </div>

                                <div className="pag_item2">
                                    <p className="pag_item_text2">1</p>
                                </div>

                                <div className="pag_item3">
                                    <p className="pag_item_text3">2</p>
                                </div>
                               
                                <div className="pag_item4">
                                    <p className="pag_item_text4">...</p>
                                </div>

                                <div className="pag_item5">
                                    <p className="pag_item_text5">9</p>
                                </div>

                                <div className="pag_item6">
                                    <p className="pag_item_text6">10</p>
                                </div>

                                <div className="pag_item7">
                                <a className="pag_item_text7" href=""><img  src={process.env.PUBLIC_URL+"rightarrow.svg"} alt="coded png"/></a>
                                </div>


                            </div>



                            <a href={process.env.PUBLIC_URL+"tenant2"}>
                            <div className="boxing">
                                <div className="boxing_case">
                                    <a className="boxing_img" href="tel:0818-371-9660"><img  src={process.env.PUBLIC_URL+"call.svg"} alt="call png"/></a>
                                    <a className="boxing_img2" href=""><img  src={process.env.PUBLIC_URL+"coded.svg"} alt="coded png"/></a>
                                </div>
                                    <img  className="thin_bar" src={process.env.PUBLIC_URL+"call.svg"} alt="line png"/>
                                    <p className="boxing_text">Anthony Anderson</p>
                                    <p className="boxing_text2">Queens’ Park</p>
                                    <a href=""><img className="boxing_img3" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>

                                <div className="boxing_location">
                                    <img className="boxing_img4" src={process.env.PUBLIC_URL+"location.svg"} alt="location-png"/>
                                    <p className="boxing_location_text">Surulere, Lagos</p>
                                </div>

                                <div className="boxing_naira ">
                                    <img className="boxing_img5" src={process.env.PUBLIC_URL+"naira.svg"} alt="naira-png"/>
                                    <h6 className="boxing_naira_text">4,500,000<span className="boxing_naira_text2">/year</span></h6>
                                </div>
                                
                                <div className="boxing_calendar">
                                    <img className="boxing_img6" src={process.env.PUBLIC_URL+"calendar.svg"} alt="calendar-png"/>
                                    <p className="boxing_calendar_text">12th June, 2022</p>
                                </div>

                                <div className="boxing_expire">
                                    <img className="boxing_img7" src={process.env.PUBLIC_URL+"time count.svg"} alt="time-png"/>
                                    <p className="boxing_expire_text">Rent expires in 6 months</p>
                                </div>



                            </div>
                            </a>

                            <a href={process.env.PUBLIC_URL+"tenant2"}>
                            <div className="boxing2">
                                <div className="boxing_case">
                                    <a className="boxing_img" href="tel:0818-371-9660"><img  src={process.env.PUBLIC_URL+"call.svg"} alt="call png"/></a>
                                    <a className="boxing_img2" href=""><img  src={process.env.PUBLIC_URL+"coded.svg"} alt="coded png"/></a>
                                </div>
                                    <img  className="thin_bar" src={process.env.PUBLIC_URL+"call.svg"} alt="line png"/>
                                    <p className="boxing_text">Anthony Anderson</p>
                                    <p className="boxing_text2">Queens’ Park</p>
                                    <a href=""><img className="boxing_img3" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>

                                <div className="boxing_location">
                                    <img className="boxing_img4" src={process.env.PUBLIC_URL+"location.svg"} alt="location-png"/>
                                    <p className="boxing_location_text">Surulere, Lagos</p>
                                </div>

                                <div className="boxing_naira ">
                                    <img className="boxing_img5" src={process.env.PUBLIC_URL+"naira.svg"} alt="naira-png"/>
                                    <h6 className="boxing_naira_text">4,500,000<span className="boxing_naira_text2">/year</span></h6>
                                </div>
                                
                                <div className="boxing_calendar">
                                    <img className="boxing_img6" src={process.env.PUBLIC_URL+"calendar.svg"} alt="calendar-png"/>
                                    <p className="boxing_calendar_text">12th June, 2022</p>
                                </div>

                                <div className="boxing_expire">
                                    <img className="boxing_img7" src={process.env.PUBLIC_URL+"time count.svg"} alt="time-png"/>
                                    <p className="boxing_expire_text">Rent expires in 6 months</p>
                                </div>



                            </div>
                            </a>


                            <a href={process.env.PUBLIC_URL+"tenant2"}>
                            <div className="boxing3">
                                <div className="boxing_case">
                                    <a className="boxing_img" href="tel:0818-371-9660"><img  src={process.env.PUBLIC_URL+"call.svg"} alt="call png"/></a>
                                    <a className="boxing_img2" href=""><img  src={process.env.PUBLIC_URL+"coded.svg"} alt="coded png"/></a>
                                </div>
                                    <img  className="thin_bar" src={process.env.PUBLIC_URL+"call.svg"} alt="line png"/>
                                    <p className="boxing_text">Anthony Anderson</p>
                                    <p className="boxing_text2">Queens’ Park</p>
                                    <a href=""><img className="boxing_img3" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>

                                <div className="boxing_location">
                                    <img className="boxing_img4" src={process.env.PUBLIC_URL+"location.svg"} alt="location-png"/>
                                    <p className="boxing_location_text">Surulere, Lagos</p>
                                </div>

                                <div className="boxing_naira ">
                                    <img className="boxing_img5" src={process.env.PUBLIC_URL+"naira.svg"} alt="naira-png"/>
                                    <h6 className="boxing_naira_text">4,500,000<span className="boxing_naira_text2">/year</span></h6>
                                </div>
                                
                                <div className="boxing_calendar">
                                    <img className="boxing_img6" src={process.env.PUBLIC_URL+"calendar.svg"} alt="calendar-png"/>
                                    <p className="boxing_calendar_text">12th June, 2022</p>
                                </div>

                                <div className="boxing_expire">
                                    <img className="boxing_img7" src={process.env.PUBLIC_URL+"time count.svg"} alt="time-png"/>
                                    <p className="boxing_expire_text">Rent expires in 6 months</p>
                                </div>



                            </div>
                            </a>
                        
                            

                            
                </div>
    </div>

        
    );
};

export default tenant;