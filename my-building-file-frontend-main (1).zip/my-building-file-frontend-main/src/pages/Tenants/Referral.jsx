import React from "react";
import "./referral.css";

const Referral = () => {
    return (

        <div className="container">
            <div className="top_nav">
                    
            <nav className="pleasant_main">
                <a className="main_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                    <div className="sidebar">
                        <div className="sidebar_list">
                                <div className="sidebar_item1">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                                </div>
                                <div className="sidebar_item2" >
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties png"/></a>
                                </div>
                                <div className="sidebar_item3">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                                </div>
                                <div className="sidebar_item4">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                                </div>
                                <div className="sidebar_item5">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                                </div>
                                <div className="sidebar_item6">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                                </div>
                                <div className="sidebar_item7">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral-active.svg"} alt="referral png"/></a>
                                </div>
                                
                            </div>
                                <div className="sidebar_logout">
                                    <a className="sidebar_tool" href={process.env.PUBLIC_URL+ "login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                                </div>
                            

                    </div>
            </nav>

            

            <div className="Messages_content">
                        <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>


                <h3 className="utility_bill_text">Referral</h3>
                    <div className="utility_bill_wrapper1">
                        <p className="utility_referral_text">Total earnings on referral for this month so far is</p>
                            <div className="referral_bill_case">
                                <h6 className="referral_bill_text3">₦ 10,000</h6>
                            </div>
                    </div>

                <div className="referral_pending_wrapper">
                    <h5 className="referral_earnings">Total Earnings</h5>
                    <div className="referral_pending">
                        <div className="referral_pending_case">
                            <div className="referral_text_wrapper">
                                <p className="referral_pending_text">Pending</p>
                                    <h3 className="referral_pending_text2">₦ 2,000</h3>
                            </div>
                        </div>
                    
                    
                        <div className="referral_pending_case1">
                            <div className="referral_text_wrapper1">
                                <h6 className="referral_pending_text3">Completed</h6>
                                <h3 className="referral_pending_text4">₦ 21,000</h3>
                            </div>
                            
                        </div>
                    </div>
                </div>

                <div className="refer_earn">
                    <div className="refer_earn_wrapper">
                        <img className="refer_earn_img" src={process.env.PUBLIC_URL+"referal group.svg"} alt="group earn.png"/>
                        <div className="invite_earn">
                            <h4 className="refer_earn_text">Invite and earn</h4>
                            <p className="refer_earn_text1">Spread the word and secure up to 2-10% in earnings when your referral completes a transaction</p>
                                <div className="refer_earn_case">
                                    <div className="refer_earn_btn">
                                        <p className="refer_earn_text2">https://refer.propcity/hendrixii5</p>
                                    </div>
                                    <div className="invite_earn_btn">
                                        <img className="refer_earn_img1" src={process.env.PUBLIC_URL+"document-copy.svg"} alt="document copy.png"/>
                                    </div>
                                </div>
                        </div>
                    </div>

                </div>
                
                <div className="refer_agent_wrapper">
                    <h5 className="refer_agent_text">Referred Agents</h5>
                    <div className="refer_table_wrapper">
                            
                                <div className="refer_agent_wrapper1">
                                    <p className="refer_agent_content">Date</p>
                                    <p className="refer_agent_content1">Name</p>
                                    <p className="refer_agent_content2">Phone number</p>
                                    <p className="refer_agent_content3">Status</p>
                                </div>

                                
                                    <div className="refer_agent_table">
                                        <div className="refer_table_content">  
                                            <div className="refer_table_column">
                                                <div className="refer_table_header">
                                                    <p className="refer_table_text">20th June 22</p>
                                                </div>
                                            </div>

                                            <div className="refer_name_wrapper">
                                                    <div className="refer_name_header">
                                                        <p className="refer_name_text">Josh Andrew</p>
                                                    </div>
                                            </div>
                                            <div className="refer_phone_wrapper">                                                    
                                                    <div className="refer_phone_header">
                                                        <p className="refer_phone_text">08012345676</p>
                                                    </div>
                                            </div>

                                            <div className="refer_status_wrapper">
                                                <div className="refer_status_header">
                                                    <p className="refer_status_text">Completed</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="refer_table_content1">  
                                            <div className="refer_table_column">
                                                <div className="refer_table_header">
                                                    <p className="refer_table_text">20th June 22</p>
                                                </div>
                                            </div>

                                            <div className="refer_name_wrapper">
                                                    <div className="refer_name_header">
                                                        <p className="refer_name_text">Josh Andrew</p>
                                                    </div>
                                            </div>
                                            <div className="refer_phone_wrapper">                                                    
                                                    <div className="refer_phone_header">
                                                        <p className="refer_phone_text">08012345676</p>
                                                    </div>
                                            </div>

                                            <div className="refer_status_wrapper">
                                                <div className="refer_status_header1">
                                                    <p className="refer_status_text1">pending</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="refer_table_content2">  
                                            <div className="refer_table_column">
                                                <div className="refer_table_header">
                                                    <p className="refer_table_text">20th June 22</p>
                                                </div>
                                            </div>

                                            <div className="refer_name_wrapper">
                                                    <div className="refer_name_header">
                                                        <p className="refer_name_text">Josh Andrew</p>
                                                    </div>
                                            </div>
                                            <div className="refer_phone_wrapper">                                                    
                                                    <div className="refer_phone_header">
                                                        <p className="refer_phone_text">08012345676</p>
                                                    </div>
                                            </div>

                                            <div className="refer_status_wrapper">
                                                <div className="refer_status_header1">
                                                    <p className="refer_status_text1">Pending</p>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                    </div>
                </div>

                <div className="referred_stat_wrapper">
                    <h5 className="referred_stat_text">Referral Stats</h5>
                        <div className="referred_invite_wrapper">
                            <h5 className="referred_invite_text">Invites</h5>
                            <div className="referred_invite_case">
                                <img className="referred_invite_content" src={process.env.PUBLIC_URL+"profile.svg"} />
                                <img className="referred_invite_content1" src={process.env.PUBLIC_URL+"profile.svg"} />
                                <img className="referred_invite_content2" src={process.env.PUBLIC_URL+"profile.svg"} />
                            </div>
                            <img className="referred_invite_img" src={process.env.PUBLIC_URL+"progress.svg"} />
                            <p className="referred_invite_text1">12 referrals</p>
                            <p className="referred_invite_text2">0 completed referrals</p>
                        </div>
                </div>

            </div>

    </div>
</div>

    
)
};

export default Referral;