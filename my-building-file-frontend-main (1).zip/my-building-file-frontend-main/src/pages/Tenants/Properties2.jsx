import React from "react";
import "./properties2.css";

const Properties2 = () => {
    return (

        <div className="container1">

            <nav className="properties_main">
                <a className="main_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                    <div className="sidebar">
                        <div className="sidebar_list">
                            <div className="sidebar_item1">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Homelandlord"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home png"/></a>
                            </div>
                            <div className="sidebar_item2" >
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"properties"}><img src={process.env.PUBLIC_URL+"properties-active.svg"} alt="properties png"/></a>
                            </div>
                            <div className="sidebar_item3">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Tenant"}><img  src={process.env.PUBLIC_URL+"tenant.svg"} alt="tenants png"/></a>
                            </div>
                            <div className="sidebar_item4">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Wallet"}><img  src={process.env.PUBLIC_URL+"wallet.svg"} alt="wallet png"/></a>
                            </div>
                            <div className="sidebar_item5">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Messages"}><img  src={process.env.PUBLIC_URL+"messages.svg"} alt="message png"/></a>
                            </div>
                            <div className="sidebar_item6">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Utility"}><img  src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility png"/></a>
                            </div>
                            <div className="sidebar_item7">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+"Referral"}><img  src={process.env.PUBLIC_URL+"referral.svg"} alt="referral png"/></a>
                            </div>
                            
                        </div>
                            <div className="sidebar_logout">
                                <a className="sidebar_tool" href={process.env.PUBLIC_URL+ "login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="referral png"/></a>
                            </div>
                            

                    </div>
            </nav>

            <div className="content3">
                <div className="Script">

                    <h3 className="script_text">Properties</h3>
                    <p className="script_open">You have listed a total of <a className="link_blue">12 properties</a></p>
                    <div className="script_search">
                            <img className="property_search_img" src={process.env.PUBLIC_URL+"search scope.svg"} alt="scope png"/>
                                <input type="text" className="property_search_input" placeholder="Search property" />
                            </div>

                    <div className="fill_line"></div>

                    <div className="ghost_fill">
                        <p className="ghost_text">All Properties</p>
                        <a className="ghost_img" href=""><img src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/></a>

                    </div>

                    <div className="proplist">
                        <div className="proplist_wrapper">
                            <img className="proplist_img" src={process.env.PUBLIC_URL+"card-image.svg"} alt="proplist img-png"/>
                            <p className="proplist_queen">Queens’ Park</p>
                            <p className="proplist_avenue">12 Avenue, Surule...</p>
                            <img className="proplist_img2" src={process.env.PUBLIC_URL+"vacant.svg"} alt="vacant img-png"/>
                            <p className="proplist_size">1280 sqm</p>
                        </div>

                        <div className="checklist_wrapper">
                            <img className="checklist_img" src={process.env.PUBLIC_URL+"card-image1.svg"} alt="proplist img-png"/>
                            <p className="checklist_queen">Queens’ Park</p>
                            <p className="checklist_avenue">12 Avenue, Surule...</p>
                            <img className="checklist_img2" src={process.env.PUBLIC_URL+"occupied.svg"} alt="occupied img-png"/>
                            <p className="checklist_size">1280 sqm</p>
                        </div>

                        <div className="proplist_wrapper2">
                            <img className="proplist_img" src={process.env.PUBLIC_URL+"card-image2.svg"} alt="proplist img-png"/>
                            <p className="proplist_queen">Queens’ Park</p>
                            <p className="proplist_avenue">12 Avenue, Surule...</p>
                            <img className="proplist_img2" src={process.env.PUBLIC_URL+"vacant.svg"} alt="vacant img-png"/>
                            <p className="proplist_size">1280 sqm</p>
                        </div>

                        
                        <div className="checklist_wrapper2">
                            <img className="checklist_img" src={process.env.PUBLIC_URL+"card-image3.svg"} alt="proplist img-png"/>
                            <p className="checklist_queen">Queens’ Park</p>
                            <p className="checklist_avenue">12 Avenue, Surule...</p>
                            <img className="checklist_img2" src={process.env.PUBLIC_URL+"occupied.svg"} alt="occupied img-png"/>
                            <p className="checklist_size">1280 sqm</p>
                        </div>
                        
                        <div className="proplist_wrapper3">
                            <img className="proplist_img" src={process.env.PUBLIC_URL+"card-image4.svg"} alt="proplist img-png"/>
                            <p className="proplist_queen">Queens’ Park</p>
                            <p className="proplist_avenue">12 Avenue, Surule...</p>
                            <img className="proplist_img2" src={process.env.PUBLIC_URL+"vacant.svg"} alt="vacant img-png"/>
                            <p className="proplist_size">1280 sqm</p>
                        </div>

                    </div>

                </div>

                    
                <a href={process.env.PUBLIC_URL+""} className="build_btn">
                    <img className="build_img" src={process.env.PUBLIC_URL+"building.svg"} alt="building-png"/><h6 className="build_img_text">Add Properties</h6>
                </a>

                <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Property Manager</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                <div className="the_place">
                    <img className="the_place_img" src={process.env.PUBLIC_URL+"the_place.svg"} alt="place_img png"/>
                    <div className="place_case">
                        <h3 className="place_text">Queens’ Park Home</h3>
                        <p className="place_text2">12 Richard Avenue, Surulere, Lagos</p>
                    </div>
                   <a href={process.env.PUBLIC_URL+""} className="place_btn"><img className="place_btn_img" src={process.env.PUBLIC_URL+"edit.svg"} alt="edit-png"/><p className="place_btn_text">Edit Property Details</p></a>
                    
                    <div className="place_features">
                        <div className="features_case">
                            <div className="closet">
                                <p className="closet_text">Properties</p>
                                <div className="closet_sub">
                                    <img className="closet_img" src={process.env.PUBLIC_URL+"group.svg"} alt="group png"/>
                                    <p className="closet_sub_text">4</p>
                                </div>
                            </div>
                            
                            <div className="closet2">
                                <p className="closet_text">Bedroom</p>
                                <div className="closet_sub">
                                    <img className="closet_img" src={process.env.PUBLIC_URL+"bedroom.svg"} alt="group png"/>
                                    <p className="closet_sub_text">6</p>
                                </div>
                            </div>

                            <div className="closet3">
                                <p className="closet_text">Bathroom</p>
                                <div className="closet_sub">
                                    <img className="closet_img" src={process.env.PUBLIC_URL+"bathroom.svg"} alt="group png"/>
                                    <p className="closet_sub_text">6</p>
                                </div>
                            </div>
                            
                            <div className="closet4">
                                <p className="closet_text4">Square area</p>
                                <div className="closet_sub4">
                                    <img className="closet_img" src={process.env.PUBLIC_URL+"size.svg"} alt="group png"/>
                                    <p className="closet_sub_text4">6 sqm</p>
                                </div>
                            </div>

                            <div className="closet5">
                                <p className="closet_text4">Status</p>
                                <div className="closet_sub5">
                                    <img className="closet_img" src={process.env.PUBLIC_URL+"tick-circle.svg"} alt="group png"/>
                                    <p className="closet_sub_text5">Available</p>
                                </div>
                            </div>

                            <div className="closet6">
                                <p className="closet_text4">Tenants</p>
                                <div className="closet_sub6">
                                    <img className="closet_img" src={process.env.PUBLIC_URL+"human.svg"} alt="group png"/>
                                    <p className="closet_sub_text5">6</p>
                                </div>
                            </div>


                        </div>
                    </div>

                    <div className="about_rack">
                        <h5 className="about_text">About Property</h5>
                        <p className="about_text2">Lorem ipsum dolor sit amet consectetur. Et lorem sit suspendisse in sem posuere nisl viverra nec. Hendrerit dui semper fames mauris. Condimentum eget lacus ipsum ut sem congue nisi. Cursus tellus aliquam augue tellus tempus sapien ultricies tincidunt.  Condimentum eget lacus ipsum ut sem congue nisi. </p>

                    </div>

                    <div className="contact_rack">
                        <h5 className="contact_rack_text">Tenants</h5>
                            <div className="contact_scroll">
                                <img className="scroll_img" src={process.env.PUBLIC_URL+"right-arrow.svg"} alt="group png"/>
                                <img className="scroll_img2" src={process.env.PUBLIC_URL+"right-arrow.svg"} alt="group png"/>
                            </div>
                        <div className="scroll_contact">
                            <a href=""><button className="scroll_contact_btn"><p className="scroll_contact_btn_text">Message</p></button></a>
                                <div className="scroll_contact_line"></div>
                                <img className="scroll_contact_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse 7 png"/>
                                <h5 className="scroll_contact_text">Andrew Tate</h5>
                                <p className="scroll_number">0804434458</p>
                                <p className="scroll_number2">Move in Date</p>
                                <p className="scroll_number3">Price per year</p>
                                <p className="scroll_number4">24 Jul 2022</p>
                                <div className="scroll_number5">
                                    <img className="scroll_naira" src={process.env.PUBLIC_URL+"naira 2.svg"} alt="naira png"/>
                                    <p className="scroll_naira_text">1,500,000</p>
                                </div>

                        </div>
                    </div>

                    <div className="scroll_rent">
                        <div className="rent_collect">
                            <h5 className="rent_collect_text">Rent collected this month</h5>
                            <div className="rent_taken">
                                <p className="rent_taken_text">35%</p>
                            </div>
                        </div>
                        <img className="rent_status_bar" src={process.env.PUBLIC_URL+"bar-status.svg"} alt="status bar png"/>

                        <div className="rent_status_wrapper">
                            <img className="rent_status_naira" src={process.env.PUBLIC_URL+"naira.svg"} alt="naira png"/>
                            <h6 className="rent_status_amount">1,500,000 collected</h6>
                        </div>

                        <div className="blue_rent_wrapper">
                            <h6 className="blue_rent_text">Out of</h6>
                            <img className="blue_rent_naira" src={process.env.PUBLIC_URL+"naira 3.svg"} alt="naira png"/>
                            <h6 className="blue_rent_text2">4,500,000</h6>
                        </div>
                    </div>
                </div>
            </div>
                
        </div>
                            
  

        
    );
};

export default Properties2;   