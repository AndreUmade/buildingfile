import React from "react";
import "./password2.css";

const Password2 = () => {
  return  (
            <div className="tenantpassword_wrapper">
                <a href="" className="tenantpassword_logo"><img src={process.env.PUBLIC_URL+"Logo.png"} alt="signin png"/></a>

                <div className="tenantpassword2_reset">
                    <h2 className="tenantpassword2_reset_text">Verify Your Email</h2>
                    <p className="tenantpassword2_reset_text1">A One Time Password has been sent to your email address, ianii****@gmail.com</p>

                    <div className="tenantpassword2_input_wrapper">
                        <div className="tenantpassword2_input_case">
                            <label for="email" className="tenantpassword2_input_text">OTP</label>
                            <div className="tenantpassword2_input_content">
                                <input className="tenantpassword2_input_fill" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                                <input className="tenantpassword2_input_fill1" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                                <input className="tenantpassword2_input_fill2" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                                <input className="tenantpassword2_input_fill3" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                                <input className="tenantpassword2_input_fill4" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                                <input className="tenantpassword2_input_fill5" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                            </div>
                        </div>
                    </div>

                    <a href={process.env.PUBLIC_URL+"resetpassword3"} className="tenantpassword2_btn">
                        <h6 className="tenantpassword2_btn_text">Proceed</h6>
                    </a>

                </div>


                <div className="tenantpassword_illustration_wrapper">
                    <img className="tenantpassword_illustration" src={process.env.PUBLIC_URL+"password ill.svg"} alt="signin png"/>
                </div>

            </div>
  );
};

export default Password2;