import React from "react";
import "./password.css";

const Password = () => {
  return  (
            <div className="tenantpassword_wrapper">
                <a href="" className="tenantpassword_logo"><img src={process.env.PUBLIC_URL+"Logo.png"} alt="signin png"/></a>

                <div className="tenantpassword_reset">
                    <h2 className="tenantpassword_text">Reset Password</h2>
                    <p className="tenantpassword_text1">Enter the email registered with your Mybuildingfile account for verification</p>

                    <div className="tenantpassword_input_wrapper">
                        <div className="tenantpassword_input_case">
                          <label for="email" className="tenantpassword_input_text">Email address</label>
                          <input className="tenantpassword_input_field" type="email" name="email" id="email" placeholder="johndoe@gmail.com"></input>
                      </div>
                    </div>

                    <a href={process.env.PUBLIC_URL+"resetpassword2"} className="tenantpassword_btn">
                        <h6 className="tenantpassword_btn_text">Proceed</h6>
                    </a>
                </div>
                <div className="tenantpassword_illustration_wrapper">
                    <img className="tenantpassword_illustration" src={process.env.PUBLIC_URL+"password ill.svg"} alt="signin png"/>
                </div>

            </div>
  );
};

export default Password;