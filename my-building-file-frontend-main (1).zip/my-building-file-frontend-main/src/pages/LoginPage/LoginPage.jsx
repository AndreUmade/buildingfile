import React from "react";
import "./loginPage.css";
import axios from "axios";
import { useState } from "react";
const url = 'http://admin.mybuildingfile.com/api/v1/tenant/register';

const LoginPage = () => {

  const [first_name, setName] = useState('')
  const [last_name, setLast] = useState('')
  const [email, setEmail] = useState('')
  const [gender, setGender] = useState('')
  const [address, setAddress] = useState('')
  const [phone, setPhone] = useState('')


  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const resp = await axios.post(url, {first_name,last_name,email,gender,address,phone});
      console.log(resp.data);
    } catch (error){
      console.log(error.response);
    }
  };
  

  return  (
    <div className="login_start">
        <div className="login_sides">
            <div className="login_logo">
              <a href=""><img src={process.env.PUBLIC_URL+"Logo.png"} alt="signin png"/></a>
            </div>

            <div className="form_head">
              <div className="form_top">
                <div className="form_sign">
                  <a href={process.env.PUBLIC_URL+"login"}><h5 className="grade1">SIGN IN</h5></a>
                  <h5 className="grade2">SIGN UP</h5> 
                </div>
                <img className="trim" src={process.env.PUBLIC_URL+"trim.png"} alt="signin png"/>
              </div>
               <div className="form_second">
                  <h6 className="welcome_text">Welcome to Mybuildingfile</h6>
                  <h2 className="form_text_two">New Account</h2>
               </div>

               <div className="form_details">
                  <div className="form_prop">
                    <img className="details_text" src={process.env.PUBLIC_URL+"one empty.svg"} alt="one png"/>
                    <p className="details_text_two">Personal Details</p>
                  </div>
                  <img className="loginvector" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow right png"/>
  

                  <div className="form_prop">
                    <img className="security_text" src={process.env.PUBLIC_URL+"two icon.png"} alt="two png"/>
                    <p className="secure_text">Security</p>
                  </div>
               </div>

               <div className="form_main">
                      <div className="full_style">
                          <label for="name" className="form_name">First name</label>
                          <input className="area_style" type="text" name="name" id="fname" value={first_name} placeholder="John Wick" onChange={(e) => setName(e.target.value)}></input>
                      </div>

                      <div className="full_style">
                          <label for="name" className="form_name">Last name</label>
                          <input className="area_style" type="text" name="name" id="lname" value={last_name} placeholder="Doe" onChange={(e) => setLast(e.target.value)}></input>
                      </div>
                      <div className="full_style">
                          <label for="email" className="form_name">Email</label>
                          <input className="area_style" type="email" name="email" id="email" value={email} placeholder="johndoe@gmail.com" onChange={(e) => setEmail(e.target.value)}></input>
                      </div>
                      <div className="full_style">
                          <label for="phone" className="form_name">Phone number</label>
                          <input className="area_style" type="tel" name="phone" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" value={phone} placeholder="+234 801 234 5678" onChange={(e) => setPhone(e.target.value)}></input>
                      </div>
                      <div className="full_style">
                          <label for="address" className="form_name">Home Address</label>
                          <input className="area_style" name="street-address" type="text" value={address} placeholder="No., Street address, city, etc." onChange={(e) => setAddress(e.target.value)} />
                      </div>

                      <div className="full_style">
                          <label for="gender" className="form_name">Gender</label>
                          <select id="gender" className="area_style" value={gender} onChange={(e) => setGender(e.target.value)}>
                            <option value="" >Select Gender</option>
                            <option value="male">male</option>
                            <option value="female">Female</option>
                            <option value="another">Others</option>
                          </select>
                      </div>
                 </div>

                 <a href={process.env.PUBLIC_URL+"createpassword"} onClick={handleSubmit} className="login_btn2">
                    <h6 className="login_button">Next</h6>
                 </a>


                 <p className="terms">By clicking the button, you agree to our <a href="#">Terms of Service</a> and have read and acknowledged our <a href="#">Privacy Policy</a></p>
                 <p className="slime">Already have an account yet? <a href={process.env.PUBLIC_URL+"login"} className="welcome_hyperlink">Log In</a></p>
            </div>
        </div> 



        <div className=" two">
          <img className="illustrate" src={process.env.PUBLIC_URL+"sign up ill.png"} alt="signin png"/>
        </div>
    </div>
  )
};
export default LoginPage;