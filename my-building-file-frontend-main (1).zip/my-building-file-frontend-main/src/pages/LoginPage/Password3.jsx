import React from "react";
import "./password3.css";

const Password3 = () => {
  return  (
            <div className="tenantpassword_wrapper">
                <a href="" className="tenantpassword_logo"><img src={process.env.PUBLIC_URL+"Logo.png"} alt="signin png"/></a>

                <div className="tenantpassword3_reset">
                    <h2 className="tenantpassword3_text">Create New Password</h2>
                    <p className="tenantpassword3_text1">Enter your new password</p>

                    <div className="tenantpassword3_input_wrapper">
                        <div className="tenantpassword3_input_content">
                            <label className="tenantpassword3_input_text" for="pwd">New Password</label>
                            <input className="tenantpassword3_input_field" type="password" id="pwd" name="pwd" placeholder="• • • • • • •"></input>
                        </div>

                        <div className="tenantpassword3_input_content1">
                            <label className="tenantpassword3_input_text1" for="pwd">Confirm Password</label>
                            <input className="tenantpassword3_input_field1" type="password" id="pwd" name="pwd" placeholder="• • • • • • •"></input>
                        </div>

                    </div>

                    <a href={process.env.PUBLIC_URL+"login"} className="tenantpassword3_btn">
                        <h6 className="tenantpassword3_btn_text">Update Password</h6>
                    </a>
                </div>


                <div className="tenantpassword_illustration_wrapper">
                    <img className="tenantpassword_illustration" src={process.env.PUBLIC_URL+"password ill.svg"} alt="signin png"/>
                </div>

            </div>
  );
};

export default Password3;