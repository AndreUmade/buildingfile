import React from "react";
import "./modalpassword.css";
import { useState } from 'react';




const ModalPassword= () => {

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true)
  
    return (
        <div show={show} onHide={handleClose}  className="modalbill" data-backdrop="static">
            <div className="modalbill_main">
            <div className="modal_bill_line"></div>
            <img className="modal_img" src={process.env.PUBLIC_URL+"close-round.svg"} />
            <div className="modal_bill_line1"></div>

            <div className="modal_bill_section">
                <div className="modal_bill_wrapper">
                    <div className="modal_bill_title">
                        <h4 className="modal_bill_text">Payment Details</h4>
                        <p className="modal_bill_text1">Enter the payment information on the tenant’s property</p>
                    </div>

                    <div className="modal_bill_input_wrapper">
                        <div className="modal_bill_input_field">
                            <label for="property" className="modal_bill_input_text">Select Property</label>
                            <select id="property" className="modal_bill_input">
                                <option value="" >Beverly House</option>
                                <option value="woman">Queen's Court</option>
                                <option value="woman">Green House</option>
                                <option value="another">Others</option>
                            </select>
                        </div>

                        <div className="modal_bill_input_field1">
                                <div className="modal_bill_input_header">
                                    <label for="amount" className="modal_bill_input_text1">Amount</label>
                                    <input type="number" min="0.00" max="100000.00" step="0.01" className="modal_bill_input1">
                                    </input>
                                    <p className="modal_bill_input_img">₦</p>
                                    <div className="modal_bill_input_img1"></div>
                                </div>
                            
                        </div>

                        <div className="modal_bill_date_wrapper">
                            <div className="modal_bill_date_header">
                                <div className="modal_bill_input_field2">
                                    <label for="start" className="modal_bill_input_text2">Date of Payment</label>
                                    <input className="modal_bill_input2" type="date" name="begin" placeholder="DD-MM-YYYY" value="" min="1997-01-01" max="2030-12-31"></input>
                                </div>

                                <div className="modal_bill_input_field3">
                                    <label className="modal_bill_input_text3" for="start">Due Date</label>
                                    <input className="modal_bill_input3" type="date" name="begin" placeholder="DD-MM-YYYY" value="" min="1997-01-01" max="2030-12-31"></input>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <a className="modal_bill_button">
                    <h6 className="modal_bill_button_text">Update Payment</h6>
                </a>
            </div>
            </div>
        </div>
    );
  };
  
 export default ModalPassword;