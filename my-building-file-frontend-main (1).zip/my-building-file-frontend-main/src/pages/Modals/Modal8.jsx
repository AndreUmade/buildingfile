import React from "react";
import "./modal8.css";



const Modal8= () => {
  
    return (
      
          <div  className="modal8_main" id="modal2" data-backdrop="static">
                <div className="modal6_top_line"></div>
                <img className="modal6_close_img" src={process.env.PUBLIC_URL+"close-round.svg"} />
                
                <h4 className="modal8_top_text">Top Up</h4>
                <div className="modal8_bank_amount">
                    <div className="modal8_bank_amount_case">
                        <h5 className="modal8_bank_amount_naira">₦</h5>
                        <h2 className="modal8_bank_amount_text">20,000</h2>
                    </div>
                    <p className="modal8_bank_amount_text1">Available Balance:
                        <p className="modal8_bank_amount_span">₦200,000</p>
                    </p>
                </div>

                <div className="modal8_line"></div>

                <div className="modal8_bank_payment">
                    <h6 className="modal8_bank_payment_text">Payment method</h6>
                    <div className="modal8_bank_payment_frame">
                        <img className="modal8_bank_payment_img" src={process.env.PUBLIC_URL+"bank2.svg"} />
                        <div className="modal8_bank_payment_content">
                            <p className="modal8_bank_payment_text1">Henry Michael</p>
                            <p className="modal8_bank_payment_text2">2044XXXXXX - United Bank for Africa</p>
                        </div>

                        <a className="modal8_bank_payment_button">
                            <img className="modal8_bank_payment_button_img" src={process.env.PUBLIC_URL+"edit active.svg"} />
                            <p className="modal8_bank_payment_button_text">Change Bank</p>
                        </a>
                    </div>
                </div>


                <a className="modal8_button" href="">
                    <h6 className="modal8_button_text">Proceed to Next Step</h6>
                </a>
          </div>
      
    );
}
  
 export default Modal8;