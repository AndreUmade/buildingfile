import React from "react";
import "./modal7.css";



const Modal7= () => {
  
    return (
      
          <div  className="modal6_main" id="modal2" data-backdrop="static">
                <div className="modal6_top_line"></div>
                <img className="modal6_close_img" src={process.env.PUBLIC_URL+"close-round.svg"} />
                <div className="modal7_detail_bank">
                    <h4 className="modal7_detail_bank_text">Confirm Account Password</h4>
                    <p className="modal7_detail_bank_text1">Enter your Mybuildingfile account password to add bank</p>
                </div>

                <div className="modal6_line"></div>

                <div className="modal6_input_wrapper">
                    <div className="modal6_input_content">
                        <div className="modal6_input_case">
                            <label for="pwd" className="modal7_input_tag">Password</label>
                            <input className="modal7_input" type="password" id="pwd" name="pwd" placeholder="•••••••••••"></input>
                        </div>
                    </div>
                </div>


                <a className="modal7_button" href="">
                    <h6 className="modal7_button_text">Back</h6>
                </a>

                <a className="modal7_button1" href="">
                    <h6 className="modal7_button_text1">Add Bank</h6>
                </a>
          </div>
      
    );
}
  
 export default Modal7;