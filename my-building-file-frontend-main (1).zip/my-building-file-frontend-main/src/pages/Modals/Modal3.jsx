import React from "react";
import "./modal3.css";



const Modal3= () => {
  
    return (
      
          <div  className="modal_main1" id="modal2" data-backdrop="static">
              <div className="modal_case1">
                <div className="modal_top_line"></div>
                <img className="modal_img" src={process.env.PUBLIC_URL+"close-round.svg"} />

                            <div className="modal1_add_property">
                                <div className="modal1_personal">
                                    <img className="modal_personal_img" src={process.env.PUBLIC_URL+"tickk.svg"} />
                                    <p className="modal3_personal_text1">Personal Details</p>
                                </div>

                                <div className="modal1_rooms">
                                    <div className="modal1_rooms_case1">
                                        <p className="modal2_rooms_text1">2</p>
                                    </div>
                                    <p className="modal1_rooms_text2">Rooms</p>
                                </div>

                                <div className="modal1_picture">
                                    <div className="modal1_picture_case">
                                        <p className="modal1_picture_text">3</p>
                                    </div>
                                    <p className="modal1_picture_text1">Pictures Upload</p>
                                </div>

                                <div className="modal1_line3"></div>
                                <div className="modal1_line2"></div>    
                            </div>
                            
                            <div className="modal2_line"></div>

                            <div className="modal1_property_detail">
                                <h4 className="modal1_prop_detail_text">Rooms</h4>
                                <p className="modal1_prop_detail_text1">Enter the details and address information of the property </p>
                            </div>

                            <div className="modal1_bed_bath">
                                <div className="modal3_bed_add_case">
                                    <div className="modal3_bath_frame">
                                        <div className="modal3_bath_content">
                                            <img className="modal3_bath_img" src={process.env.PUBLIC_URL+"bathroom.svg"} />
                                            <p className="modal3_bath_text">Bathroom</p>
                                        </div>
                                        <div className="modal3_line"></div>
                                        <div className="modal3_bath_count">
                                            <img className="modal3_bath_low" src={process.env.PUBLIC_URL+"minus.svg"} />
                                                <h6 className="modal3_bath_figure">1</h6>
                                                <img className="modal3_bath_high" src={process.env.PUBLIC_URL+"add1.svg"} />
                                            </div>
                                    </div>

                                </div>

                                <div className="modal3_bath_add_case">
                                    <div className="modal3_bed_frame">
                                        <div className="modal3_bed_content">
                                            <img className="modal3_bed_img" src={process.env.PUBLIC_URL+"bedroom.svg"} />
                                            <p className="modal3_bed_text">Bedroom</p>
                                        </div>
                                        <div className="modal3_line"></div>
                                        <div className="modal3_bed_count">
                                            <img className="modal3_bed_low" src={process.env.PUBLIC_URL+"minus.svg"} />
                                                <h6 className="modal3_bed_figure">1</h6>
                                                <img className="modal3_bed_high" src={process.env.PUBLIC_URL+"add1.svg"} />
                                            </div>
                                    </div>

                                </div>

                                
                            </div>
              </div>

              <div className="modal1_button_case">
                    <a className="modal1_button" href="">
                        <h6 className="modal1_button_text">Back</h6>
                    </a>

                    <a className="modal3_button1" href="">
                        <h6 className="modal3_button_text1">Proceed to Next Step</h6>
                    </a>
              </div>

          </div>
      
    );
}
  
 export default Modal3;