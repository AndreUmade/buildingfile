import React from "react";
import "./modal6.css";



const Modal6= () => {
  
    return (
      
          <div  className="modal6_main" id="modal2" data-backdrop="static">
                <div className="modal6_top_line"></div>
                <img className="modal6_close_img" src={process.env.PUBLIC_URL+"close-round.svg"} />
                <div className="modal6_detail_bank">
                    <h4 className="modal6_detail_bank_text">Enter Bank Details</h4>
                    <p className="modal6_detail_bank_text1">Kindly enter and save your account information securely for subsequent withdrawal on your wallet</p>
                </div>

                <div className="modal6_line"></div>

                <div className="modal6_input_wrapper">
                    <div className="modal6_input_content">
                        <div className="modal6_input_case">
                            <label for="fname" className="modal6_field_tag">Account number</label>
                            <input className="modal6_field_input" type="text" id="fname" name="fname" placeholder="Enter Account Number" />
                        </div>
                    </div>

                    <div className="modal6_input_content1">
                        <div className="modal6_input_case1">
                            <label for="gender" className="modal6_field_tag1">Bank Name</label>
                            <select id="gender" className="modal6_field_input1">
                                <option value="" >--</option>
                                <option value="access">Access Bank</option>
                                <option value="fidelity">Fidelity Bank</option>
                                <option value="another">Guaranty Trust Bank</option>
                                <option value="another">United Bank of Africa</option>
                                <option value="another">Zenith Bank</option>
                          </select>
                          <p className="modal6_input_text">Account info doesn’t match</p>
                        </div>
                         
                    </div>
                </div>

                <a className="modal6_button" href="">
                    <h6 className="modal6_button_text">Procced</h6>
                </a>
          </div>
      
    );
}
  
 export default Modal6;