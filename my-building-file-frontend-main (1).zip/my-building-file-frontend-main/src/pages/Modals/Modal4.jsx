import React from "react";
import "./modal4.css";



const Modal4= () => {
  
    return (
      
          <div  className="modal_main1" id="modal2" data-backdrop="static">
              <div className="modal_case1">
                <div className="modal_top_line"></div>
                <img className="modal_img" src={process.env.PUBLIC_URL+"close-round.svg"} />

                            <div className="modal1_add_property">
                                <div className="modal1_personal">
                                    <img className="modal_personal_img" src={process.env.PUBLIC_URL+"tickk.svg"} />
                                    <p className="modal3_personal_text1">Personal Details</p>
                                </div>

                                <div className="modal1_rooms">
                                        <img className="modal_personal_img" src={process.env.PUBLIC_URL+"tickk.svg"} />
                                    <p className="modal4_rooms_text2">Rooms</p>
                                </div>

                                <div className="modal1_picture">
                                    <div className="modal4_picture_case">
                                        <p className="modal4_picture_text">3</p>
                                    </div>
                                    <p className="modal4_picture_text1">Pictures Upload</p>
                                </div>

                                <div className="modal1_line3"></div>
                                <div className="modal1_line4"></div>    
                            </div>
                            
                            <div className="modal2_line"></div>

                            <div className="modal1_property_detail">
                                <h4 className="modal4_prop_detail_text">Pictures Upload</h4>
                                <p className="modal1_prop_detail_text1">Kindly upload photos of the property. Make sure to add photos of the rooms and important features </p>
                            </div>

                            <div className="modal4_image_input">
                                <div className="modal4_image_input_case">
                                    <div className="modal4_image_input_content">
                                        <img className="modal4_personal_img" src={process.env.PUBLIC_URL+"add.svg"} />
                                    </div>

                                    <div className="modal4_image_input_content1">
                                        <img className="modal4_personal_img1" src={process.env.PUBLIC_URL+"add.svg"} />
                                    </div>

                                    <div className="modal4_image_input_content2">
                                        <img className="modal4_personal_img2" src={process.env.PUBLIC_URL+"add.svg"} />
                                    </div>
                                </div>
                            </div>

              </div>

              <div className="modal1_button_case">
                    <a className="modal1_button" href="">
                        <h6 className="modal1_button_text">Back</h6>
                    </a>

                    <a className="modal4_button1" href="">
                        <h6 className="modal4_button_text1">Add New Property</h6>
                    </a>
              </div>

          </div>
      
    );
}
  
 export default Modal4;