import React from "react";
import "./modal2.css";
import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';



const Modal2= () => {

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true)
  
    return (
        <Modal show={show} onHide={handleClose} id="modal2" className="modal_main1" data-backdrop="static">
       
          <div  className="modal2_main1" >
         
              <div className="modal_case1">
                <div className="modal_top_line"></div>
                <img className="modal_img" src={process.env.PUBLIC_URL+"close-round.svg"} onClick={handleClose} />

                            <div className="modal2_add_property">
                                <div className="modal2_personal">
                                    <img className="modal_personal_img" src={process.env.PUBLIC_URL+"tickk.svg"} />
                                    <p className="modal2_personal_text1">Personal Details</p>
                                </div>

                                <div className="modal1_rooms">
                                    <div className="modal1_rooms_case1">
                                        <p className="modal2_rooms_text1">2</p>
                                    </div>
                                    <p className="modal1_rooms_text2">Rooms</p>
                                </div>

                                <div className="modal1_picture">
                                    <div className="modal1_picture_case">
                                        <p className="modal1_picture_text">3</p>
                                    </div>
                                    <p className="modal1_picture_text1">Pictures Upload</p>
                                </div>

                                <div className="modal1_line3"></div>
                                <div className="modal1_line2"></div>    
                            </div>

                            <div className="modal2_line"></div>

                            <div className="modal1_property_detail">
                                <h4 className="modal1_prop_detail_text">Rooms</h4>
                                <p className="modal1_prop_detail_text1">Enter the details and address information of the property </p>
                            </div>

                            <div className="modal1_bed_bath">
                                <div className="modal1_bed_add_case">
                                    <div className="modal1_bath_frame">
                                        <img className="modal1_bath_img" src={process.env.PUBLIC_URL+"bathroom.svg"} />
                                        <p className="modal1_bath_text">Bathroom</p>
                                    </div>

                                </div>

                                <div className="modal1_bed_add_case">
                                    <div className="modal1_bed_frame">
                                        <img className="modal1_bed_img" src={process.env.PUBLIC_URL+"bedroom.svg"} />
                                        <p className="modal1_bed_text">Bedroom</p>
                                    </div>

                                </div>
                            </div>
              </div>

              <div className="modal1_button_case">
                    <a className="modal1_button" href="">
                        <h6 className="modal1_button_text">Back</h6>
                    </a>

                    <a className="modal1_button1" href="">
                        <h6 className="modal1_button_text1">Proceed to Next Step</h6>
                    </a>
              </div>
             
          </div>
        </Modal>
    );
  }
  
 export default Modal2;