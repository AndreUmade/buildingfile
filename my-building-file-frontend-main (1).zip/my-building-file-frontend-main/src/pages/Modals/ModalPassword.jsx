import React from "react";
import "./modalpassword.css";
import { useState } from 'react';
import { Modal } from "react-bootstrap";




const ModalPassword= () => {

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true)
  
    return (
        <Modal show={show} onHide={handleClose}  className="modalbill1" data-backdrop="static">
            <div className="modalbill1_main">
            <div className="modal_bill1_line"></div>
            <img className="modal1_img" src={process.env.PUBLIC_URL+"close-round.svg"} onClick={handleClose}/>
            <div className="modal_bill1_line1"></div>

            
                
                    <div className="modal_bill1_title">
                        <h4 className="modal_bill1_text">Bill Details</h4>
                        <p className="modal_bill1_text1">Enter the details of the bill you paid for</p>
                    </div>


                    <div className="modal_bill1_wrapper">
                        <div className="modal_bill1_input_wrapper">
                            <div className="modal_bill1_input_field">
                                <label for="property" className="modal_bill1_input_text">Property</label>
                                <select id="property" className="modal_bill1_input" placeholder="Beverly House">
                                    <option value="" >Beverly House</option>
                                    <option value="woman">Queen's Court</option>
                                    <option value="woman">Green House</option>
                                    <option value="another">Others</option>
                                </select>
                            </div>
                            <div className="modal_bill1_input_field1">
                                <label for="property" className="modal_bill1_input_text1">Bill name</label>
                                <select id="property" className="modal_bill1_input1" placeholder="Select Bill">
                                    <option value="" >Select Bill</option>
                                    <option value="woman">Queen's Court</option>
                                    <option value="woman">Green House</option>
                                    <option value="another">Others</option>
                                </select>
                            </div>
                        </div>

                        <div className="modalbill1_amount_wrapper">
                            <div className="modalbill1_amount_content">
                                <div className="modal_amount_field1">
                                    <label for="amount" className="modal_amount_input_text1">Amount</label>
                                    <input type="number" min="0.00" max="100000.00" step="0.01" className="modal_bill1_input2" placeholder="0.00">
                                    </input>
                                    <p className="modal_amount_input_img">₦</p>
                                    <div className="modal_amount_input_img1"></div>
                                </div>

                                
                                <div className="modalbill1_date_header">
                                        <label for="start" className="modalbill1_input_text2">Date of Payment</label>
                                        <input className="modalbill1_input2" type="date" name="begin" placeholder="DD-MM-YYYY" value="" min="1997-01-01" max="2030-12-31"></input>
                                </div>
                            </div>
                        </div>
                    
                </div>
                
                
                <div className="modalbill1_button_wrapper">
                    <a className="modal_bill1_button" onClick={handleClose}>
                        <h6 className="modal_bill1_button_text">Back</h6>
                    </a>

                    <a className="modal_bill1_button1">
                        <h6 className="modal_bill1_button_text1">Proceed to Next Step</h6>
                    </a>
                </div>
               
            </div>
        </Modal>
    );
  };
  
 export default ModalPassword;