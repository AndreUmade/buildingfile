import React from 'react';
import "./modal1.css";
import { openModal } from '../../features/modal/modalSlice';
import { closeModal } from '../../features/modal/modalSlice';
import { useDispatch } from 'react-redux';
 
function Modal1() {
  const dispatch = useDispatch
    return (
        <div className="modal_main" >
       
                <div className="modal_case">
                    <div className="modal_top_line"></div>
                    <img className="modal_img" src={process.env.PUBLIC_URL+"close-round.svg"} onClick={() => dispatch(closeModal())}/>
                                
                        <div className="modal1_add_property">
                            <div className="modal1_personal">
                                <div className="modal1_personal_case">
                                    <p className="modal1_personal_text">1</p>
                                </div>
                                <p className="modal1_personal_text1">Personal Details</p>
                            </div>

                            <div className="modal1_rooms">
                                <div className="modal1_rooms_case">
                                    <p className="modal1_rooms_text">2</p>
                                </div>
                                <p className="modal1_rooms_text1">Rooms</p>
                            </div>

                            <div className="modal1_picture">
                                <div className="modal1_picture_case">
                                    <p className="modal1_picture_text">3</p>
                                </div>
                                <p className="modal1_picture_text1">Pictures Upload</p>
                            </div>
                            <div className="modal1_line1"></div>
                            <div className="modal1_line2"></div>
                        </div>

                            <div className="modal1_line"></div>


                            <div className="modal1_property_detail">
                                <h4 className="modal1_prop_detail_text">Property Details</h4>
                                <p className="modal1_prop_detail_text1">Enter the details and address information of the property </p>
                            </div>

                    <div className="modal1_fields">
                        <div className="modal1_field_frame">
                            <div className="modal1_field_content">
                                <label for="fname" className="modal1_field_tag">Name of Property</label>
                                <input className="modal1_field_input" type="text" id="fname" name="fname" placeholder="Beverly House" />
                            </div>

                            <div className="modal1_field_content1">
                                <label for="fname" className="modal1_field_tag1">Size<p className="modal1_field_tag1_text">(in sqm)</p></label>
                                <input className="modal1_field_input1" type="number" id="fname" name="fname" placeholder="62" />
                            </div>
                        </div>

                        <div className="modal1_field_frame1">
                            <div className="modal1_field_content2">
                                <label for="fname" className="modal1_field_tag2">Property Description</label>
                                <textarea className="modal1_field_input2" type="text" id="fname" name="fname" placeholder="Enter description here..."/>
                            </div>
                        </div>

                        <div className="modal1_field_frame2">
                            <div className="modal1_field_content3">
                                <label for="fname" className="modal1_field_tag3">Street Address</label>
                                <input className="modal1_field_input3" type="text" id="fname" name="fname" placeholder="Beverly House" />
                            </div>
                        </div>

                        <div className="modal1_field_frame3">
                            <div className="modal1_field_content4">
                                <label for="fname" className="modal1_field_tag4">City</label>
                                <input className="modal1_field_input4" type="text" id="fname" name="fname" placeholder="Beverly House" />
                            </div>

                            <div className="modal1_field_content5">
                                <label for="fname" className="modal1_field_tag5">State</label>
                                <input className="modal1_field_input5" type="text" id="fname" name="fname" placeholder="Beverly House" />
                            </div>
                        </div>
                    
                    </div>

                    <div className="modal1_btn_wrapper">
                        <a data-dismiss="modal_main1" data-toggle="modal2_main1" href="#modal2" className="modal1_btn" >
                            <h6 className="modal1_btn_text">Proceed to Next Step</h6>
                        </a>
                    </div>
            </div>
        </div>

    );
    
};



export default Modal1;
