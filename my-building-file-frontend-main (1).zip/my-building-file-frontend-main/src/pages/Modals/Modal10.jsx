import React from "react";
import "./modal10.css";



const Modal10= () => {
  
    return (
      
          <div  className="modal10_main" id="modal2" data-backdrop="static">
                <div className="modal6_top_line"></div>
                <img className="modal6_close_img" src={process.env.PUBLIC_URL+"close-round.svg"} />
                
                <h4 className="modal8_top_text">Withdraw</h4>
                
                <div className="modal8_line"></div>


                <div className="modal10_">
                    <h6 className="modal10_">Amount</h6>
                    <p className="modal10_">The amount will be transferred into your account below</p>
                </div>

                <h4 className="modal10_">₦20,000</h4>

                <div className="modal10_bank_payment">
                    <h6 className="modal8_bank_payment_text">To</h6>
                    <div className="modal8_bank_payment_frame">
                        <img className="modal8_bank_payment_img" src={process.env.PUBLIC_URL+"bank2.svg"} />
                        <div className="modal8_bank_payment_content">
                            <p className="modal8_bank_payment_text1">Henry Michael</p>
                            <p className="modal8_bank_payment_text2">2044XXXXXX - United Bank for Africa</p>
                        </div>

                        <a className="modal8_bank_payment_button">
                            <img className="modal8_bank_payment_button_img" src={process.env.PUBLIC_URL+"edit active.svg"} />
                            <p className="modal8_bank_payment_button_text">Change Bank</p>
                        </a>
                    </div> 
                </div>

                <div className="modal10_">
                    <div className="modal10_">
                        <h6 className="modal10_">Enter Verification Code</h6>
                        <p className="modal10_">We have sent a 6-digit code to the phone number attached to your bank account. The code will expire in  15 minutes. Contact your bank if you have trouble getting this code</p>
                    </div>
 
                    <div>
                            <input className="modal10_" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                            <input className="modal10_" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                            <input className="modal10_" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                            <input className="modal10_" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                            <input className="modal10_" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                            <input className="modal10_" name="pincode" type="text" inputmode="numeric" pattern="[0-9]{1}" maxlength="1" placeholder="•"></input>
                    </div>  

                    <h6 className="modal10_">Resending code in 14:30s</h6>
                    <h6 className="modal10_  ">14:30s</h6>

                    <a className="modal10_button" href="">
                        <h6 className="modal8_button_text">Proceed to Next Step</h6>
                    </a>
                    <a className="modal10_button1" href="">
                        <h6 className="modal8_button_text">Proceed to Next Step</h6>
                    </a>
                </div>
          </div>
      
    );
}
  
 export default Modal10;