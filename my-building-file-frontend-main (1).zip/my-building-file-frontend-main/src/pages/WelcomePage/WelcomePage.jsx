import React from "react";
import "./welcomePage.css";
import axios from "axios";
import { useState } from "react";
const url = 'http://admin.mybuildingfile.com/api/v1/manager/login';
// Accept : 'application/json'

const WelcomePage = () => {
  const [password, setPassword] = useState('')
  const [email, setEmail] = useState('')
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    try { 
      const resp = await axios.post(url, {password,email});
      console.log(resp.data);
    } catch (error){
      console.log(error.response);
    }
  };

  
  return (

   
            <div className="welcomepage_wrapper">
                  <div className="logo_start">
                    <a href="#"><img src={process.env.PUBLIC_URL+"Logo.png"} alt="signin png"/></a>
                  </div>

                  <div className="welcomepage_form">
                    <div className="form_top">
                      <div className="form_header_sign">
                        <a href={process.env.PUBLIC_URL+"login"}><h5 className="header_text">SIGN IN</h5></a>
                        <a href={process.env.PUBLIC_URL+"signup"}><h5 className="header_text2">SIGN UP</h5></a>
                      </div>
                      <img className="trim_two" src={process.env.PUBLIC_URL+"trim2.png"} alt="signin png"/>
                    </div>
                    <div className="form_second">
                        <h6 className="form_intro_text">Welcome to Mybuildingfile</h6>
                        <h2 className="form_header_text">Get back in</h2>
                    </div>

                    <form className="main_form" onSubmit={handleSubmit}>
                      <div className="form_style">
                          <label for="email" className="form_text">Email</label>
                          <input className="area_style" type="email" name="email" id="email" value={email} placeholder="johndoe@gmail.com"   onChange={(e) => setEmail(e.target.value)}></input>                      </div>

                      <div className="form_style">
                          <label for="pwd" className="form_text">Confirm Password</label>
                          <input className="area_style" type="password" name="pwd" id="pwd" value={password} placeholder="••••••••••"   onChange={(e) => setPassword(e.target.value)}></input>
                      </div>
                    </form>

                    <a href={process.env.PUBLIC_URL+"homelandlord"} onClick={handleSubmit} className="welcomepage_button"><h6 className="welcomepage_button_text">Log In</h6></a>
                    <p className="center">Don’t have an account yet? <a href={process.env.PUBLIC_URL+"signup"} className="welcome_hyperlink">Sign Up</a></p>

                  </div>
            

                <div className="welcomepage_ill">
                  <img className="illustrate" src={process.env.PUBLIC_URL+"sign in ill.png"} alt="signin png"/>
                </div>
            </div>
            
  );
};

export default WelcomePage;

