import React from "react";
import "./tenantproperties2.css";


const TenantProperties2 = () => {
        return(
                    <div className="tenantproperty_page_wrapper">
                        <div className="tenantproperty_sidebar_wrapper">
                            <a className="hometenant_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                            <div className="hometenant_header">
                                <div className="hometenant_header_list">
                                    <div className="hometenant_content">
                                        <a className="hometenant_list_text" href={process.env.PUBLIC_URL+"hometenant"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home.png"/></a>
                                    </div>
                                    <div className="hometenant_content1">
                                        <a className="hometenant_list_text1" href={process.env.PUBLIC_URL+"tenantproperties"}><img src={process.env.PUBLIC_URL+"properties-active.svg"} alt="properties.png"/></a>
                                    </div>
                                    <div className="hometenant_content2">
                                        <a className="hometenant_list_text2" href={process.env.PUBLIC_URL+"tenantmessages"}><img src={process.env.PUBLIC_URL+"messages.svg"} alt="messages.png"/></a>
                                    </div>
                                    <div className="hometenant_content3">
                                        <a className="hometenant_list_text3" href={process.env.PUBLIC_URL+"tenantutility"}><img src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility bills.png"/></a>
                                    </div>
                                </div>
                                <div className="hometenant_content4">
                                        <a className="hometenant_list_text4" href={process.env.PUBLIC_URL+"tenantregistration"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="log out.png"/></a>
                                </div>
                            </div>
                        </div>
                        

                        <div className="hometenant_content_wrapper">
                            <h3 className="anderson_text">Properties</h3>
                                <p className="anderson_text2">12 properties from your property manager</p>


                                <div className="message_notification">
                                <div className="messages_notif_wrapper">
                                    <a href={process.env.PUBLIC_URL+"tenantprofile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Tenant</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"tenantprofile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                                <div className="tenantproperty_nested">
                                    <div className="tenantproperty_nested_case">


                                        <div className="tenantproperty_nest3">
                                            <a href={process.env.PUBLIC_URL+"tenantproperties"}><p className="tenantproperty_nest_flow2">All Properties</p></a>
                                        </div>
                                        <div className="tenantproperty_nest4">
                                            <a href=""><p className="tenantproperty_nest_flow3">My Properties</p></a>
                                        </div>

                                    </div>
                                </div>

                                <div className="tenantproperty_card_wrapper">
                                    <div className="tenantproperty_overdue_header">
                                        <img className="tenantproperty_card_img" src={process.env.PUBLIC_URL+"rectangle img.svg"} alt=" png"/>
                                        <div className="tenantproperty_card_overdue_content">
                                            <h4 className="tenantproperty_card_text">₦ 800,000</h4>
                                            <h6 className="tenantproperty_card_text_span">/year</h6>
                                            <h4 className="tenantproperty_card_text1">Queens’ Park</h4>
                                            <p className="tenantproperty_card_text2">12 Avenue, Baptist Estate, Surulere, Lagos</p>
                                            <div className="tenantproperty_card_line"></div>
                                            <div className="tenantproperty_card_overdue">
                                                <img className="tenantproperty_card_overdue_img" src={process.env.PUBLIC_URL+"Ellipse 29.svg"} alt=" png"/>
                                                <p className="tenantproperty_card_overdue_text">Rent is overdue</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="tenantproperty_overdue_header1">
                                        <img className="tenantproperty_card_img" src={process.env.PUBLIC_URL+"rectangle img.svg"} alt=" png"/>
                                        <div className="tenantproperty_card_overdue_content">
                                            <h4 className="tenantproperty_card_text">₦ 800,000</h4>
                                            <h6 className="tenantproperty_card_text_span">/year</h6>
                                            <h4 className="tenantproperty_card_text1">Queens’ Park</h4>
                                            <p className="tenantproperty_card_text2">12 Avenue, Baptist Estate, Surulere, Lagos</p>
                                            <div className="tenantproperty_card_line"></div>
                                            <div className="tenantproperty_card_overdue1">
                                                <div className="tenantproperty_card_overdue_case">
                                                    <img className="tenantproperty_card_overdue_img1" src={process.env.PUBLIC_URL+"Ellipse 29.svg"} alt=" png"/>
                                                    <img className="tenantproperty_card_overdue_img2" src={process.env.PUBLIC_URL+"Ellipse 30.svg"} alt=" png"/>
                                                </div>
                                                <p className="tenantproperty_card_overdue_text1">Rent expires in 6 months, 12 days</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    
                        </div>
                            
                    </div>
    )
};

export default TenantProperties2;