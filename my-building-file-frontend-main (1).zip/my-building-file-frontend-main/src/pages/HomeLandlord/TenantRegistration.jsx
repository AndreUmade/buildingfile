import React from "react";
import "./tenantregistration.css";
import axios from "axios";
import { useState } from "react";
const url = 'http://admin.mybuildingfile.com/api/v1/tenant/register';


const Tenantregistration = () => {

const [password, setPassword] = useState('')
  const [email, setEmail] = useState('')
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const resp = await axios.post(url, {password,email});
      console.log(resp.data);
    } catch (error){
      console.log(error.response);
    }
  };

        return(
            <div className="tenantreg_wrapper">
                    <div className="tenantreg_header">
                        <a className="tenantreg_logo" href=""><img src={process.env.PUBLIC_URL+"Logo.png"} alt="logo-png"/></a>
                    </div>
                    <h2 className="tenantreg_text">Tenant Registration</h2>
                    <div className="tenantreg_prop_add">
                            <div className="tenantreg_personal">
                                <div className="tenantreg_personal_content">
                                    <p className="tenantreg_personal_text">1</p>
                                </div>
                                <p className="tenantreg_personal_text1">Personal Details</p>
                            </div>

                            <img className="tenantreg_personal_img" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow right.png"/>
                            
                            <div className="tenantreg_security">
                                <div className="tenantreg_security_content">
                                    <p className="tenantreg_security_text">2</p>
                                </div>
                                <p className="tenantreg_security_text1">Security</p>
                            </div>

                            <img className="tenantreg_security_img" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow right.png"/>

                            <div className="tenantreg_guarantor">
                                <div className="tenantreg_guarantor_content">
                                    <p className="tenantreg_guarantor_text">3</p>
                                </div>
                                <p className="tenantreg_guarantor_text1">Guarantor’s form</p>
                            </div>
                    </div>

                    <div className="tenantreg_manager">
                        <img className="tenantreg_manager_img" src={process.env.PUBLIC_URL+"Ellipse 27.svg"} alt="profile img.png"/>
                        <div className="tenantreg_manager_line"></div>
                        <div className="tenantreg_manager_content">
                            <h5 className="tenantreg_manager_text">Mark Tony</h5>
                            <p className="tenantreg_manager_text1">Property Manager</p>
                        </div>
                    </div>

                    <div className="tenantreg_manager_line1"></div>

                    <div className="tenantreg_detials">
                        <h4 className="tenantreg_detials_text">Personal Details</h4>
                        <h6 className="tenantreg_detials_text1">Kindly fill in the blanks so your personal information can be recorded</h6>
                    </div>

                    <div className="tenantreg_app_field">
                        <div className="tenantreg_app_content">
                            <h5 className="tenantreg_app_text">Applicant Information</h5>
                            <div className="tenantreg_app_header">
                                <div className="tenantreg_app_tile">
                                            <div className="tenantreg_info_first">
                                                <label for="name" className="tenantreg_info_text">First name</label>
                                                <input className="tenantreg_info_input" type="text" name="name" id="fname" placeholder="First name"></input>
                                            </div>

                                            <div className="tenantreg_info_first1">
                                                <label for="name" className="tenantreg_info_text">Last name</label>
                                                <input className="tenantreg_info_input" type="text" name="name" id="fname" placeholder="Last name"></input>
                                            </div>
                                </div>

                                <div className="tenantreg_app_tile1">
                                            <div className="tenantreg_info_email">
                                            <label for="email" className="tenantreg_email_text">Email</label>
                                            <input className="tenantreg_email_input" type="email" name="email" id="email" placeholder="example@gmail.com"></input>
                                            </div>

                                            <div className="tenantreg_info_phone">
                                                <label for="phone" className="tenantreg_email_text">Phone number</label>
                                                <input className="tenantreg_email_input" type="tel" name="phone" placeholder="+(234) 801 234 5678"></input>
                                            </div>
                                </div>

                                <div className="tenantreg_app_tile2">
                                            <div className="tenantreg_info_address">
                                                <label for="address" className="tenantreg_address_text">Former Home Address</label>
                                                <input className="tenantreg_address_input" name="street-address" type="text" placeholder="No., Street address, city, etc." required />
                                            </div>

                                            <div className="tenantreg_info_date">
                                                <label for="date" className="tenantreg_address_text">Date of Birth</label>
                                                <input className="tenantreg_date_input" type="date" id="start" name="start"  min="1900-01-01" max="2050-12-31" />
                                            </div>
                                </div>

                                <div className="tenantreg_app_tile3">
                                            <div className="tenantreg_info_gender">
                                            <label for="gender" className="tenantreg_gender_text">Gender</label>
                                                        <select id="gender" className="tenantreg_gender_input">
                                                            <option value="">Select Gender</option>
                                                            <option value="woman">Male</option>
                                                            <option value="woman">Female</option>
                                                            <option value="another">Others</option>
                                                        </select>
                                            </div>

                                            <div className="tenantreg_info_marital">
                                            <label for="gender" className="tenantreg_marital_text">Marital Status</label>
                                                        <select id="gender" className="tenantreg_gender_input">
                                                            <option value="">Select status</option>
                                                            <option value="woman">Single</option>
                                                            <option value="woman">Married</option>
                                                            <option value="another">Divorced</option>
                                                            <option value="another">widowed</option>
                                                        </select>
                                            </div>
                                </div>
 
                                <div className="tenantreg_app_tile4">
                                            <div className="tenantreg_info_office">
                                                <label for="address" className="tenantreg_office_text">Office Address</label>
                                                <input className="tenantreg_office_input" name="office-address" type="text" placeholder="No., Street address, city, etc." required />
                                            </div>

                                            <div className="tenantreg_info_occupation">
                                                <label for="occupation" className="tenantreg_office_text">Occupation</label>
                                                <input className="tenantreg_office_input" name="occupation" type="text" placeholder="Enter Occupation" required />
                                            </div>
                                </div>

                                <div className="tenantreg_app_tile5">
                                            <div className="tenantreg_info_state">
                                                <label for="address" className="tenantreg_state_text">State of Origin</label>
                                                <input className="tenantreg_state_input" name="state" type="text" placeholder="Rivers State" required />
                                            </div>

                                            <div className="tenantreg_info_religion">
                                                <label for="gender" className="tenantreg_state_text">Religion</label>
                                                            <select id="gender" className="tenantreg_state_input">
                                                                <option value="">Select status</option>
                                                                <option value="woman">Christainity</option>
                                                                <option value="woman">Islamic</option>
                                                                <option value="another">Others</option>
                                                            </select>
                                            </div>
                                </div>
                                
                            </div>
                        </div>
                    
                    
                        <div className="tenantreg_upload">
                            <h5 className="tenantreg_upload_text">Upload your Photo</h5>
                            <div className="tenantreg_upload_case">
                                <div className="tenantreg_upload_header">
                                    <img className="tenantreg_upload_img" src={process.env.PUBLIC_URL+"file upload.svg"} alt="logo-png"/>
                                    <div className="tenantreg_upload_content">
                                        <img className="tenantreg_upload_img1" src={process.env.PUBLIC_URL+"clock.svg"} alt="logo-png"/>
                                        <p className="tenantreg_upload_text1">Upload Pending</p>
                                    </div>
                                </div>

                                <div className="tenantreg_upload_line"></div>

                                <div className="tenantreg_drag">
                                    <p className="tenantreg_drag_text">Drag and drop photo here</p>
                                    <div className="tenantreg_drag_case">
                                        <div className="tenantreg_drag_line"></div>
                                        <p className="tenantreg_drag_text1">Or</p>
                                        <div className="tenantreg_drag_line1"></div>
                                    </div>
                                    <a href="" className="tenantreg_drag_btn"><p className="tenantreg_drag_btn_text">Browse device</p></a>
                                    <p className="tenantreg_drag_text2">Max 2MB  limit - jpg, jpeg, png</p>
                                </div>

                            </div>
                        </div>

                        <div className="tenantreg_kyc">
                            <h5 className="tenantreg_kyc_text">Upload KYC Info</h5>
                            <div className="tenantreg_kyc_case">
                                <p className="tenantreg_kyc_text1">Select a form of Identification from the following:</p>
                                    <div className="tenantreg_kyc_content">
                                        <div className="tenantreg_kyc_header">
                                            <input className="tenantreg_kyc_input" type="radio" id="html" name="NIN" value="NIN" />
                                            <label for="html" className="tenantreg_kyc_text3">National Identification Number</label>
                                        </div>

                                        <div className="tenantreg_kyc_header1">
                                            <input className="tenantreg_kyc_input1" type="radio" id="html" name="passport" value="NIN" />
                                            <label for="html" className="tenantreg_kyc_text3">International Passport</label>
                                        </div>

                                        <div className="tenantreg_kyc_header2">
                                            <input className="tenantreg_kyc_input1" type="radio" id="html" name="license" value="NIN" />
                                            <label for="html" className="tenantreg_kyc_text3">Driver's License</label>
                                        </div>
                                    </div>
                            </div>





                            
                                    <div className="tenantreg_upload_case">
                                            <div className="tenantreg_upload_header">
                                                <img className="tenantreg_upload_img" src={process.env.PUBLIC_URL+"file upload.svg"} alt="logo-png"/>
                                                <div className="tenantreg_upload_content">
                                                    <img className="tenantreg_upload_img1" src={process.env.PUBLIC_URL+"clock.svg"} alt="logo-png"/>
                                                    <p className="tenantreg_upload_text1">Upload Pending</p>
                                                </div>
                                            </div>

                                            <div className="tenantreg_upload_line"></div>

                                    <div className="tenantreg_drag">
                                        <p className="tenantreg_drag_text">Drag and drop photo here</p>
                                        <div className="tenantreg_drag_case">
                                            <div className="tenantreg_drag_line"></div>
                                            <p className="tenantreg_drag_text1">Or</p>
                                            <div className="tenantreg_drag_line1"></div>
                                        </div>
                                        <a href="" className="tenantreg_drag_btn"><p className="tenantreg_drag_btn_text">Browse device</p></a>
                                        <p className="tenantreg_drag_text2">Max 2MB  limit - jpg, jpeg, png</p>
                                    </div>
                                </div>
                            </div>

                            <div className="tenant_bottom_line"></div>
                            <a href={process.env.PUBLIC_URL+"tenantregistration2"} className="tenant_registration_btn"><h6 className="tenant_registration_btn_text">Continue</h6></a>

                </div>
        </div>
    )
};

export default Tenantregistration;