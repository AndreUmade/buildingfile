import React from "react";


const TenantProfile = () => {
    return (

        <div className="pleasant">
            <div className="top_nav">
                    
            <nav className="pleasant_main">
                        <div className="hometenant_sidebar_wrapper">
                            <a className="hometenant_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                            <div className="hometenant_header">
                                <div className="hometenant_header_list">
                                    <div className="hometenant_content">
                                        <a className="hometenant_list_text" href={process.env.PUBLIC_URL+"hometenant"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home.png"/></a>
                                    </div>
                                    <div className="hometenant_content1">
                                        <a className="hometenant_list_text1" href={process.env.PUBLIC_URL+"tenantproperties"}><img src={process.env.PUBLIC_URL+"properties.png"} alt="properties.png"/></a>
                                    </div>
                                    <div className="hometenant_content2">
                                        <a className="hometenant_list_text2" href={process.env.PUBLIC_URL+"tenantmessages"}><img src={process.env.PUBLIC_URL+"messages.svg"} alt="messages.png"/></a>
                                    </div>
                                    <div className="hometenant_content3">
                                        <a className="hometenant_list_text3" href={process.env.PUBLIC_URL+"tenantutility"}><img src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility bills.png"/></a>
                                    </div>
                                </div>
                                <div className="hometenant_content4">
                                        <a className="hometenant_list_text4" href={process.env.PUBLIC_URL+"login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="log out.png"/></a>
                                </div>
                            </div>
                        </div>
            </nav>

            

            <div className="Messages_content">

                <div className="profile_content_wrapper">
                    <h3 className="profile_header_text">Profile</h3>
                    <div className="profile_header_line"></div>
                        <div className="profile_content_wrapper1">
                            <div className="profile_content_case">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"person.svg"} alt="referral png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Personal Information</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div>

                            <a href={process.env.PUBLIC_URL+"tenantprofile2"}><div className="profile_content_case1">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"padlock.svg"} alt="secure png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Security</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div></a>

                            <a href={process.env.PUBLIC_URL+"tenantprofile3"}><div className="profile_content_case2">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"subscribe.svg"} alt="subscribe png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Subscriptions</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div></a>
                        </div>
                </div>

                
                <div className="message_notification">
                                    <div className="messages_notif_wrapper">
                                    <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Tenant</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"tenantprofile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                <div className="personal_info_wrapper">
                    <h4 className="personal_info_text">Personal Information</h4>
                        <div className="personal_info_case">
                                <div className="personal_info_header">
                                    <div className="personal_avatar_wrapper">
                                        <p className="personal_avatar_text">Avatar</p>

                                        <div className="personal_avatar_case">
                                            <img className="personal_avatar_img" src={process.env.PUBLIC_URL+"profile avatar.svg"} alt="profile avatar png"/>
                                                <div className="personal_avatar_content">
                                                      <a href=" ">  <button className="personal_avatar_btn"><h6 className="personal_avatar_text1">Upload an avatar</h6></button></a>
                                                        <a href=""><button  className="personal_avatar_btn1"><h6 className="personal_avatar_text2">Remove</h6></button></a>
                                                </div>
                                        </div>
                                    </div>
                                    <div className="personal_avatar_line"></div>

                                    <div className="avatar_field_wrapper">


                                            <div className="avatar_field_case">
                                                    <div className="avatar_field_style">
                                                        <div className="avatar_field_header">
                                                            <label for="name" className="avatar_field_text">First name</label>
                                                            <input className="avatar_field_input" type="text" name="name" id="fname" placeholder="Andrew"></input>
                                                        </div>
                                                    </div>

                                                    <div className="avatar_field_style1">
                                                        <div className="avatar_field_header">
                                                            <label for="name" className="avatar_field_text">Last name</label>
                                                            <input className="avatar_field_input" type="text" name="name" id="lname" placeholder="Tate"></input>
                                                        </div>
                                                    </div>
                                            </div>
                                            

                                            <div className="avatar_field_case1">
                                                    <div className="avatar_field_style2">
                                                        <div className="avatar_field_header2">
                                                            <label for="email" className="avatar_field_text2">Email</label>
                                                            <input className="avatar_field_input2" type="email" name="email" id="email" placeholder="johndoe@gmail.com"></input>
                                                        </div>
                                                    </div>
                                                    <div className="avatar_field_style3">
                                                        <div className="avatar_field_header2">
                                                            <label for="phone" className="avatar_field_text2">Phone number</label>
                                                            <input className="avatar_field_input2" type="tel" name="phone" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" placeholder="+(234) 801 234 5678"></input>
                                                        </div>
    
                                                    </div>
                                            </div>
                                            
                                            <div className="avatar_field_case2">
                                                    <div className="avatar_field_style4">
                                                        
                                                            <label for="date" className="avatar_field_text3">Date of Birth</label>
                                                            <input className="avatar_field_input3" type="date" id="start" name="start"  min="1900-01-01" max="2050-12-31" />
                                                    </div>

                                                    <div className="avatar_field_style5">
                                                        <label for="gender" className="avatar_field_text3">Gender</label>
                                                        <select id="gender" className="avatar_field_input3">
                                                            <option value="">Select Gender</option>
                                                            <option value="woman">Male</option>
                                                            <option value="woman">Female</option>
                                                            <option value="another">Others</option>
                                                        </select>
                                                    </div>
                                            </div>
 
                                    </div>

                                    <div className="avatar_field_line"></div>

                                </div>

                                <a href="" className="avatar_last_btn"><h6 className="avatar_last_text">Save Changes</h6></a>
                        </div>
                </div>
            </div>
    </div>
</div>

    
)
};

export default TenantProfile;