import React from "react";
import "./tenantmessages2.css";

const TenantMessages2 = () => {
    return (

        <div className="pleasant">
            <div className="top_nav">
                    
            <nav className="pleasant_main">
            <div className="tenantproperty_sidebar_wrapper">
                            <a className="hometenant_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                            <div className="hometenant_header">
                                <div className="hometenant_header_list">
                                    <div className="hometenant_content">
                                        <a className="hometenant_list_text" href={process.env.PUBLIC_URL+"hometenant"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home.png"/></a>
                                    </div>
                                    <div className="hometenant_content1">
                                        <a className="hometenant_list_text1" href={process.env.PUBLIC_URL+"tenantproperties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties.png"/></a>
                                    </div>
                                    <div className="hometenant_content2">
                                        <a className="hometenant_list_text2" href={process.env.PUBLIC_URL+""}><img src={process.env.PUBLIC_URL+"messages-active.svg"} alt="messages.png"/></a>
                                    </div>
                                    <div className="hometenant_content3">
                                        <a className="hometenant_list_text3" href={process.env.PUBLIC_URL+"tenantutility"}><img src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility bills.png"/></a>
                                    </div>
                                </div>
                                <div className="hometenant_content4">
                                        <a className="hometenant_list_text4" href={process.env.PUBLIC_URL+"login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="log out.png"/></a>
                                </div>
                            </div>
                        </div>

            </nav>

            

            <div className="Messages_content">
                <div className="message_wrapper">
                    <h3 className="script_text">Messages</h3>
                    <p className="script_open">You have  <a className="link_blue">2 new messages</a></p>
                    <div className="script_search">
                            <img className="property_search_img" src={process.env.PUBLIC_URL+"search scope.svg"} alt="scope png"/>
                                <input type="text" className="property_search_input" placeholder="Search property" />
                            </div>
                        <div className="fill_line"></div>

                        <div className="ghost_fill">
                        <p className="ghost_text">All Messages</p>
                        <a className="ghost_img" href=""><img src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/></a>
                        </div>

                        <div className="message_case">
                        <a href={process.env.PUBLIC_URL+"tenantmessages2"}><div className="message_case_wrapper">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                                <div className="message_time_amount">
                                    <p className="message_time_text2">2</p>
                                </div>
                            </div>
                        </div></a>
                        
                        <a href={process.env.PUBLIC_URL+"messages2"}>
                        <div className="message_case_wrapper2">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                                <div className="message_time_amount">
                                    <p className="message_time_text2">2</p>
                                </div>
                            </div>
                        </div></a>

                        <a href={process.env.PUBLIC_URL+"messages2"}>
                        <div className="message_case_empty_wrapper3">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                                <img className="message_ticks" src={process.env.PUBLIC_URL+"two-ticks.svg"} alt="two-ticks png"/>
                            </div>
                        </div></a>

                        <div className="message_case_wrapper4">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                                <img className="message_ticks" src={process.env.PUBLIC_URL+"one-tick.svg"} alt="two-ticks png"/>
                            </div>
                        </div>

                        <div className="message_case_wrapper5">
                            <img className="message_case_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="ellipse png"/>
                            <p className="message_case_text">Lawrence Mark</p>
                            <p className="message_case_text2">Checking out the apartment and it does not look bad at all</p>
                            <div className="message_time_wrapper">
                                <p className="message_time_text">12:45 am</p>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="message_notification">
                            <div className="messages_notif_wrapper">
                            <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Tenant</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"profile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                  <div className="message_empty_state">
                        <div className="chat_empty_state">
                            <div className="chat_empty_state_wrapper">
                                <img className="chat_empty_state_img" src={process.env.PUBLIC_URL+"chat-ill.svg"} alt="message empty png"/>
                                <img className="chat_empty_state_img2" src={process.env.PUBLIC_URL+"chat-ill2.svg"} alt="message empty png"/>
                            </div>

                            <p className="chat_empty_state_text">Select  one of your tenants and start a conversation with them and probably close a deal</p>
                        </div>
                    
                  </div>
                
                
                

            </div>
        </div>

    </div>
    )
};

export default TenantMessages2;