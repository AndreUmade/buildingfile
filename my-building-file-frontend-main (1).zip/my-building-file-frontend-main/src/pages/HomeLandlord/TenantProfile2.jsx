import React from "react";
import "./tenantprofile2.css";
import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';


const TenantProfile2 = () => {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true)

    return (

        <div className="pleasant">


<Modal show={show} onHide={handleClose}  className="modalpassword" data-backdrop="static">
       
      <div className="modal-content1">
       <div className="modalpassword_top_line"></div>
       <img className="modalpassword_img" src={process.env.PUBLIC_URL+"close-round.svg"} onClick={handleClose} />


       <div className="modalpassword_content">
           <div className="modalpassword_change">
               <h4 className="modalpassword_change_text">Change Password</h4>
               <p className="modalpassword_change_text2">Enter your old password before creating the new one for your account</p>
           </div>

           <div className="modalpassword_input_header">
               <div className="modalpassword_input_field">
                   <label for="pwd" className="modalpassword_input_text">Old Password</label>
                   <input className="modalpassword_input" type="password" name="pwd" id="pwd" placeholder="••••••••••"></input>
               </div>
               <div className="modalpassword_input_field1">
                   <label for="pwd" className="modalpassword_input_text">New Password</label>
                   <input className="modalpassword_input" type="password" name="pwd" id="pwd" placeholder="••••••••••"></input>
               </div>
               <div className="modalpassword_input_field2">
                   <label for="pwd" className="modalpassword_input_text2">Confirm Password</label>
                   <input className="modalpassword_input" type="password" name="pwd" id="pwd" placeholder="••••••••••"></input>
               </div>
               
           </div>
       </div>

       <a className="modalpassword_button" href={process.env.PUBLIC_URL+"profile2"} onClick={handleClose}>
           <h6 className="modalpassword_button_text">Update Password</h6>
       </a>
       </div>
 

</Modal>

            <div className="top_nav">
                    
            <nav className="pleasant_main">
                <div className="hometenant_sidebar_wrapper">
                            <a className="hometenant_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                            <div className="hometenant_header">
                                <div className="hometenant_header_list">
                                    <div className="hometenant_content">
                                        <a className="hometenant_list_text" href={process.env.PUBLIC_URL+"hometenant"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home.png"/></a>
                                    </div>
                                    <div className="hometenant_content1">
                                        <a className="hometenant_list_text1" href={process.env.PUBLIC_URL+"tenantproperties"}><img src={process.env.PUBLIC_URL+"properties.png"} alt="properties.png"/></a>
                                    </div>
                                    <div className="hometenant_content2">
                                        <a className="hometenant_list_text2" href={process.env.PUBLIC_URL+"tenantmessages"}><img src={process.env.PUBLIC_URL+"messages.svg"} alt="messages.png"/></a>
                                    </div>
                                    <div className="hometenant_content3">
                                        <a className="hometenant_list_text3" href={process.env.PUBLIC_URL+"tenantutility"}><img src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility bills.png"/></a>
                                    </div>
                                </div>
                                <div className="hometenant_content4">
                                        <a className="hometenant_list_text4" href={process.env.PUBLIC_URL+"login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="log out.png"/></a>
                                </div>
                            </div>
                        </div>
            </nav>

            

            <div className="Messages_content">

                <div className="profile_content_wrapper">
                    <h3 className="profile_header_text">Profile</h3>
                    <div className="profile_header_line"></div>
                        <div className="profile_content_wrapper1">
                        <a href={process.env.PUBLIC_URL+"tenantprofile"}><div className="profile_content_case3">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"personal-inactive.svg"} alt="referral png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Personal Information</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div></a>

                            <a href=""><div className="profile_content_case4">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"Security-active.svg"} alt="secure png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Security</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div></a>

                            <a href={process.env.PUBLIC_URL+"tenantprofile3"}><div className="profile_content_case5">
                                <div className="profile_content_info">
                                    <img className="profile_content_img" src={process.env.PUBLIC_URL+"subscribe.svg"} alt="subscribe png"/>
                                    <div className="profile_content_detail ">
                                        <p className="profile_content_text">Subscriptions</p>
                                        <p className="profile_content_text1">Manage your personal info</p>
                                    </div>
                                </div>
                            </div></a>
                        </div>
                </div>

                
                <div className="message_notification">
                                    <div className="messages_notif_wrapper">
                                    <a href={process.env.PUBLIC_URL+"profile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Tenant</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"tenantprofile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

                <div className="security_field_wrapper">
                    <h4 className="security_field_text">Security</h4>
                        <div className="security_field_case">
                                <div className="security_field_content">
                                    <div className="security_field_input">
                                        <div className="security_password_wrapper">
                                            <p className="security_password_text">Password</p>
                                                <a className="security_password_input" onClick={handleShow} >
                                                    <p className="security_password_text1">Change Password</p>
                                                    <img className="security_password_img" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow-right png"/>
                                                </a>
                                        </div>

                                        <div className="security_verify_wrapper">
                                            <div className="security_verify_content">
                                                    <p className="security_verify_text">Enable 2-step verification</p>
                                                    <h6 className="security_verify_text1">Make your account extra secure. Along with your password, you’ll need to enter a code that we text to your phone each time you sign in.</h6>
                                            </div>
                                            <div className="security_switch_wrapper">
                                                <label className="switch">
                                                <input type="checkbox" />
                                                <span className="slider round"></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    <div className="security_field_line"></div>

                                <div className="security_step_wrapper">
                                        <div className="security_step_content">
                                            <p className="security_step_text">Delete Account</p>
                                            <h6 className="security_step_text1">Delete your account and all the app data</h6>
                                        </div>
                                        <a href="" className="security_step_btn"><p className="security_step_btn_text">Delete Account</p></a>
                                </div>

                                <div className="security_field_line1"></div>
                            </div>

                            <a className="security_last_btn" href=""><h6 className="security_last_btn_text">Save Changes</h6></a>
                    </div>
                </div>
            </div>
    </div>
</div>

    
)
};

export default TenantProfile2;