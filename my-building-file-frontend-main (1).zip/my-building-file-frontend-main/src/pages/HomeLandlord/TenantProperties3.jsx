import React from "react";
import "./tenantproperties3.css";


const TenantProperties3 = () => {
        return(
                    <div className="tenantproperty_page_wrapper">
                        <div className="tenantproperty_sidebar_wrapper">
                            <a className="hometenant_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                            <div className="hometenant_header">
                                <div className="hometenant_header_list">
                                    <div className="hometenant_content">
                                        <a className="hometenant_list_text" href={process.env.PUBLIC_URL+"hometenant"}><img src={process.env.PUBLIC_URL+"home.svg"} alt="home.png"/></a>
                                    </div>
                                    <div className="hometenant_content1">
                                        <a className="hometenant_list_text1" href={process.env.PUBLIC_URL+"tenantproperties"}><img src={process.env.PUBLIC_URL+"properties.svg"} alt="properties.png"/></a>
                                    </div>
                                    <div className="hometenant_content2">
                                        <a className="hometenant_list_text2" href={process.env.PUBLIC_URL+"tenantmessages"}><img src={process.env.PUBLIC_URL+"messages.svg"} alt="messages.png"/></a>
                                    </div>
                                    <div className="hometenant_content3">
                                        <a className="hometenant_list_text3" href={process.env.PUBLIC_URL+"tenantutility"}><img src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility bills.png"/></a>
                                    </div>
                                </div>
                                <div className="hometenant_content4">
                                        <a className="hometenant_list_text4" href={process.env.PUBLIC_URL+"tenantregistration"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="log out.png"/></a>
                                </div>
                            </div>
                        </div>

                            <div className="tenantproperty3_content_wrapper">
                            <a href={process.env.PUBLIC_URL+"tenantproperties"}><div className="tenantproperty3_backbtn_wrapper">
                                    <img className="tenantproperty3_back_img" src={process.env.PUBLIC_URL+"arrow-left.svg"} alt="arrow-left.png"/>
                                    <h6 className="tenantproperty3_back_text">Back to Properties</h6>
                                </div>
                            </a>
                            
                            <h3 className="tenantproperty3_content_text">Beverly Courts</h3>
                            <p className="tenantproperty3_content_text1">12 Avenue, Baptist Estate, Surulere, Lagos</p>
                            <img className="tenantproperty3_content_img" src={process.env.PUBLIC_URL+"Rectangle 1.svg"} alt="Rectangle 1.png"/>

                            <div className="tenantproperty3_images_wrapper">
                                <div className="tenantproperty3_images_case">
                                    <div className="tenantproperty3_images_content">
                                        <img className="tenantproperty3_images" src={process.env.PUBLIC_URL+"Rectangle 2.svg"} alt="Rectangle 2.png"/>
                                    </div>
                                    <div className="tenantproperty3_images_content1">
                                        <img className="tenantproperty3_images1" src={process.env.PUBLIC_URL+"Rectangle 3.svg"} alt="Rectangle 3.png"/>
                                    </div>
                                    <div className="tenantproperty3_images_content2">
                                        <img className="tenantproperty3_images2" src={process.env.PUBLIC_URL+"Rectangle 4.svg"} alt="Rectangle 4.png"/>
                                    </div>
                                </div>
                                <div className="tenantproperty3_images_scroll">
                                    <p className="tenantproperty3_images_scroll_img">Scroll to see more pictures</p>
                                </div>
                            </div>


                            <div className="tenantproperty3_place_features">
                                <div className="tenantproperty3_place_features_wrapper">
                                    
                                    <div className="tenantproperty3_closet1">
                                        <p className="closet_text">Bedroom</p>
                                        <div className="tenantproperty3_closet_sub">
                                            <img className="closet_img" src={process.env.PUBLIC_URL+"bedroom active.svg"} alt="group png"/>
                                            <p className="closet_sub_text">6</p>
                                        </div>
                                    </div>

                                    <div className="tenantproperty3_closet2">
                                        <p className="closet_text">Bathroom</p>
                                        <div className="tenantproperty3_closet_sub">
                                            <img className="closet_img" src={process.env.PUBLIC_URL+"bathroom active.svg"} alt="group png"/>
                                            <p className="closet_sub_text">6</p>
                                        </div>
                                    </div>
                                    
                                    <div className="tenantproperty3_closet3">
                                        <p className="closet_text4">Square area</p>
                                        <div className="closet_sub4">
                                            <img className="closet_img" src={process.env.PUBLIC_URL+"apartment.svg"} alt="group png"/>
                                            <p className="closet_sub_text4">6 sqm</p>
                                        </div>
                                    </div>

                                    <div className="tenantproperty3_closet4">
                                        <p className="closet_text4">Type</p>
                                        <div className="closet_sub5">
                                            <img className="closet_img" src={process.env.PUBLIC_URL+"safe-home.svg"} alt="group png"/>
                                            <p className="closet_sub_text5">Residential</p>
                                        </div>
                                    </div>

                                    <div className="tenantproperty3_closet5">
                                        <p className="closet_text4">Status</p>
                                        <div className="closet_sub6">
                                            <img className="closet_img" src={process.env.PUBLIC_URL+"tick-circle.svg"} alt="group png"/>
                                            <p className="closet_sub_text5">Available</p>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div className="tenantproperty3_rentprice_wrapper">
                                <p className="tenantproperty3_rentprice_text">Rent Price</p>
                                <div className="tenantproperty3_rentprice_content">
                                    <h4 className="tenantproperty3_rentprice_text1">₦ 800,000</h4>
                                    <h6 className="tenantproperty3_rentprice_text2">/year</h6>
                                </div>
                                <a className="tenantproperty3_rentprice_btn" href={process.env.PUBLIC_URL+"tenantmessages"}><p className="tenantproperty3_rentprice_btn_text">Send a Message</p></a>

                                <div className="tenantproperty3_rentprice_line"></div>
                                <div className="tenantproperty3_rentprice_contact_wrapper">
                                    <p className="tenantproperty3_rentprice_text3">Get Contact Info</p>
                                    <a className="tenantproperty3_rentprice_number">
                                        <p className="tenantproperty3_rentprice_text4">Copy number</p>
                                        <img className="tenantproperty3_rentprice_img" src={process.env.PUBLIC_URL+"Copy 1.svg"} alt="group png"/>
                                    </a>
                                </div>
                            </div>

                            <div className="tenantproperty3_about_rack">
                                <div className="tenantproperty3_about_content">
                                    <h5 className="tenantproperty3_about_text">About Property</h5>
                                    <p className="tenantproperty3_about_text2">Lorem ipsum dolor sit amet consectetur. Et lorem sit suspendisse in sem posuere nisl viverra nec. Hendrerit dui semper fames mauris. Condimentum eget lacus ipsum ut sem congue nisi. Cursus tellus aliquam augue tellus tempus sapien ultricies tincidunt.  Condimentum eget lacus ipsum ut sem congue nisi. </p>
                                </div>
                            </div>
                    </div>


</div>
)
}

export default TenantProperties3;