import React from "react";
import "./tenantregistration2.css";


const Tenantregistration2 = () => {
        return(
                <div className="tenantreg2_wrapper">
                    <div className="tenantreg_header">
                        <a className="tenantreg_logo" href=""><img src={process.env.PUBLIC_URL+"Logo.png"} alt="logo-png"/></a>
                    </div>
                            <h2 className="tenantreg_text">Tenant Registration</h2>
                            <div className="tenantreg_prop_add">
                                    <div className="tenantreg_personal">
                                        <img className="tenantreg_personal_content" src={process.env.PUBLIC_URL+"good tick.svg"} alt="logo-png"/>
                                        <p className="tenantreg_personal_text1">Personal Details</p>
                                    </div>

                                    <img className="tenantreg_personal_img" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow right.png"/>
                                    
                                    <div className="tenantreg_security">
                                        <div className="tenantreg2_security_content">
                                            <p className="tenantreg2_security_text">2</p>
                                        </div>
                                        <p className="tenantreg_security_text1">Security</p>
                                    </div>

                                    <img className="tenantreg_security_img" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow right.png"/>

                                    <div className="tenantreg_guarantor">
                                        <div className="tenantreg_guarantor_content">
                                            <p className="tenantreg_guarantor_text">3</p>
                                        </div>
                                        <p className="tenantreg_guarantor_text1">Guarantor’s form</p>
                                    </div>
                            </div>

                            <div className="tenantreg_manager">
                                <img className="tenantreg_manager_img" src={process.env.PUBLIC_URL+"Ellipse 27.svg"} alt="profile img.png"/>
                                <div className="tenantreg_manager_line"></div>
                                <div className="tenantreg_manager_content">
                                    <h5 className="tenantreg_manager_text">Mark Tony</h5>
                                    <p className="tenantreg_manager_text1">Property Manager</p>
                                </div>
                            </div>

                            <div className="tenantreg_manager_line1"></div>

                            <div className="tenantreg_detials">
                                <h4 className="tenantreg_detials_text">Security</h4>
                                <h6 className="tenantreg_detials_text1">Kindly  enter your preferred password to use on this platform</h6>
                            </div>

                            <div className="tenantreg_password_wrapper">
                                <h5 className="tenantreg_password_text">Password</h5>
                                <div className="tenantreg_password_header">
                                    <div className="tenantreg_password_case">
                                        <div className="tenantreg_password_content">
                                            <label for="pwd" className="tenantreg_password_text1">Enter Password</label>
                                            <input className="tenantreg_password_input" type="password" name="pwd" id="pwd" placeholder="••••••••••"></input>
                                        </div>
                                    </div>
                                    <div className="tenantreg_password_case1">
                                        <div className="tenantreg_password_content">
                                            <label for="pwd" className="tenantreg_password_text2">Confirm Password</label>
                                            <input className="tenantreg_password_input" type="password" name="pwd" id="pwd" placeholder="••••••••••"></input>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div className="tenantreg_password_line"></div>

                            <div className="tenantreg_password_decide">
                                <a className="tenantreg_password_btn" href={process.env.PUBLIC_URL+"tenantregistration"}><h6 className="tenantreg_password_btn_text">Previous</h6></a>
                                <a className="tenantreg_password_btn1" href={process.env.PUBLIC_URL+"tenantregistration3"}><h6 className="tenantreg_password_btn_text1">Continue</h6></a>
                            </div>
                </div>
            
    )
};

export default Tenantregistration2;