import React from "react";
import "./hometenant.css";


const HomeTenant = () => {
        return(
                    <div className="hometenant_wrapper">
                        <div className="hometenant_sidebar_wrapper">
                            <a className="hometenant_logo" href=""><img src={process.env.PUBLIC_URL+"main-logo.png"} alt="logo-png"/></a>
                            <div className="hometenant_header">
                                <div className="hometenant_header_list">
                                    <div className="hometenant_content">
                                        <a className="hometenant_list_text" href={process.env.PUBLIC_URL+"hometenant"}><img src={process.env.PUBLIC_URL+"home active.svg"} alt="home.png"/></a>
                                    </div>
                                    <div className="hometenant_content1">
                                        <a className="hometenant_list_text1" href={process.env.PUBLIC_URL+"tenantproperties"}><img src={process.env.PUBLIC_URL+"properties.png"} alt="properties.png"/></a>
                                    </div>
                                    <div className="hometenant_content2">
                                        <a className="hometenant_list_text2" href={process.env.PUBLIC_URL+"tenantmessages"}><img src={process.env.PUBLIC_URL+"messages.svg"} alt="messages.png"/></a>
                                    </div>
                                    <div className="hometenant_content3">
                                        <a className="hometenant_list_text3" href={process.env.PUBLIC_URL+"tenantutility"}><img src={process.env.PUBLIC_URL+"utilitybill.svg"} alt="utility bills.png"/></a>
                                    </div>
                                </div>
                                <div className="hometenant_content4">
                                        <a className="hometenant_list_text4" href={process.env.PUBLIC_URL+"login"}><img src={process.env.PUBLIC_URL+"logout.svg"} alt="log out.png"/></a>
                                </div>
                            </div>
                        </div>

                        <div className="hometenant_content_wrapper">
                            <div className="content_top">
                                    <p className="top_text">Mon, 12th Nov 2022</p>
                                    <h3 className="top_greet">Hello, <b>Andrew</b></h3>
                            </div>

                            <div className="message_notification">
                                <div className="messages_notif_wrapper">
                                    <a href={process.env.PUBLIC_URL+"tenantprofile"}><img className="message_notif_img" src={process.env.PUBLIC_URL+"Ellipse 7.svg"} alt="Ellipse-png"/></a>
                                    <div className="msg_wrapper">
                                        <h6 className="msg_wrapper_text">Hendrix James</h6>
                                        <p className="msg_wrapper_text2">Tenant</p>
                                    </div>

                                <div class="wrapper2">
                                    <input id="toggler" type="checkbox"/>
                                    <label for="toggler">
                                        <img className="utility_wrapper_img" src={process.env.PUBLIC_URL+"arrow-down.svg"} alt="arrow-down png"/>
                                    </label>
                                    <div className="notif_dropdown">
                                        <div className="notif_dropdown_case">
                                            <a className="notif_dropdown_style" href={process.env.PUBLIC_URL+"tenantprofile"}>
                                                <img className="notif_dropdown_img" src={process.env.PUBLIC_URL+"profile dropdown.svg"} alt="padlock png"/> 
                                                <p className="notif_dropdown_text">Profile</p>
                                            </a>
                                            <div className="notif_dropdown_line"></div>
                                            <a className="notif_dropdown_style1" href={process.env.PUBLIC_URL+"login"}>
                                                <img className="notif_dropdown_img1" src={process.env.PUBLIC_URL+"logout dropdown.svg"} alt="logout png"/>
                                                <p className="notif_dropdown_text1">Log out</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                            <div className="hometenant_metrics_wrapper">
                                <div className="hometenant_metrics_content">
                                    <img className="hometenant_metrics_img" src={process.env.PUBLIC_URL+"tray.svg"} alt="tray png"/>
                                    <h6 className="hometenant_metrics_text">Property Metrics</h6>
                                </div>

                                <div className="hometenant_purchased_wrapper">
                                    <div className="hometenant_purchased_content">
                                        <img className="hometenant_purchased_img" src={process.env.PUBLIC_URL+"tray2.svg"} alt="tray2 ill" /> 

                                        <div className="hometenant_purchased_case">
                                            <h4 className="hometenant_purchased_text">0</h4>
                                            <p className="hometenant_purchased_text1">Purchased</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="hometenant_available_wrapper">
                                    <div className="hometenant_available_content">
                                        <div className="hometenant_available_case">
                                            <img className="hometenant_available_img" src={process.env.PUBLIC_URL+"house.svg"} alt="tray3 ill" /> 
                                        </div>
                                            <div className="hometenant_available_case1">
                                                <h4 className="hometenant_available_text">4</h4>
                                                <p className="hometenant_available_text1">Available</p>
                                            </div>
                                    </div>
                                </div>

                                <div className="hometenant_metrics_line"></div>

                                <div className="hometenant_countdown_wrapper">
                                    <div className="hometenant_countdown_content">
                                        <img className="hometenant_countdown_img" src={process.env.PUBLIC_URL+"clock.svg"} alt="clock ill" /> 
                                    </div>
                                    <h6 className="hometenant_countdown_text">Countdown to earliest Expiry</h6>
                                </div>

                                <div className="hometenant_timing_wrapper">
                                    <p className="hometenant_timing_text">0 months 0 days left</p>
                                    <img className="hometenant_timing_img" src={process.env.PUBLIC_URL+"Ellipse 29.svg"} alt="Ellipse 29" /> 
                                    <img className="hometenant_timing_img1" src={process.env.PUBLIC_URL+"Ellipse 30.svg"} alt="Ellipse 30" /> 
                                </div>
                            </div>

                            <div className="hometenant_manager">
                                <img className="hometenant_manager_img" src={process.env.PUBLIC_URL+"Ellipse 27.svg"} alt="profile img.png"/>
                                <div className="hometenant_manager_line"></div>
                                    <div className="hometenant_manager_content">
                                        <h5 className="hometenant_manager_text">Ella Tony</h5>
                                        <p className="hometenant_manager_text1">Property Manager</p>
                                        <a href={process.env.PUBLIC_URL+"tenantmessages"} className="hometenant_manager_btn"><p className="hometenant_manager_btn_text">Message</p></a>
                                    </div>
                            </div>

                            <div className="hometenant_transact">
                                                    <h5 className="hometenant_transact_text">Transactions</h5>
                                                    <p className="hometenant_transact_text1">Date</p>
                                                    <p className="hometenant_transact_text2">Property</p>
                                                    <p className="hometenant_transact_text3">Bill</p>
                                                    <p className="hometenant_transact_text4">Deposit</p>
                                                    <p className="hometenant_transact_text5">Status</p>

                                                        <div className="hometenant_transact_table">
                                                            <div className="hometenant_transact_case">  
                                                                <div className="hometenant_table_case">
                                                                    <div className="case_table">
                                                                        <p className="table_case_text">20th June 22</p>
                                                                    </div>

                                                                </div>

                                                                <div className="hometenant_beverly_transact">
                                                                    <img className="transact_img" src={process.env.PUBLIC_URL+"Ellipse 13.png"} alt="ellipse ill" />
                                                                        <div className="beverly_case">
                                                                            <p className="beverly_case_text">Beverly Hills</p>
                                                                            <p className="beverly_case_text2">Lagos, Nigeria</p>
                                                                        </div>
                                                                </div>

                                                                <div className="hometenant_water_transact">
                                                                    <div className="water_case">
                                                                        <p className="water_case_text">Rent</p>
                                                                    </div>
                                                                </div>

                                                                <div className="hometenant_amount_transact">
                                                                    <div className="amount_case">
                                                                        <div className="hometenant_case_amount">
                                                                            <p className="hometenant_amount_case_text">+</p>
                                                                            <p className="hometenant_amount_case_text2">₦ 1,250,000</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div className="hometenant_status_transact">
                                                                    <div className="status_case">
                                                                        <div className="case_status">
                                                                            <p className="status_case_text">Successful</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <img className="hometenant_status_img" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow-right.png" />

                                                            </div>

                                                            <div className="hometenant_transact_case">  
                                                                <div className="hometenant_table_case">
                                                                    <div className="case_table">
                                                                        <p className="table_case_text">20th June 22</p>
                                                                    </div>

                                                                </div>

                                                                <div className="hometenant_beverly_transact">
                                                                    <img className="transact_img" src={process.env.PUBLIC_URL+"Ellipse 13.png"} alt="ellipse ill" />
                                                                        <div className="beverly_case">
                                                                            <p className="beverly_case_text">Beverly Hills</p>
                                                                            <p className="beverly_case_text2">Lagos, Nigeria</p>
                                                                        </div>
                                                                    

                                                                </div>
                                                                
                                                                <div className="hometenant_water_transact">
                                                                    <div className="water_case">
                                                                        <p className="water_case_text">Water Bill</p>
                                                                    </div>
                                                                </div>

                                                                <div className="hometenant_amount_transact">
                                                                    <div className="amount_case">
                                                                        <div className="case_amount">
                                                                            <p className="amount_case_text">+</p>
                                                                            <p className="amount_case_text2">₦ 50,000</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div className="hometenant_status_transact">
                                                                    <div className="status_case">
                                                                        <div className="hometenant_case_status">
                                                                            <p className="hometenant_status_case_text">Pending</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <img className="hometenant_status_img" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow-right.png" />

                                                        </div>

                                                        <div className="hometenant_transact_case">  
                                                                <div className="hometenant_table_case">
                                                                    <div className="case_table">
                                                                        <p className="table_case_text">20th June 22</p>
                                                                    </div>

                                                                </div>

                                                                <div className="hometenant_beverly_transact">
                                                                    <img className="transact_img" src={process.env.PUBLIC_URL+"Ellipse 13.png"} alt="ellipse ill" />
                                                                        <div className="beverly_case">
                                                                            <p className="beverly_case_text">Beverly Hills</p>
                                                                            <p className="beverly_case_text2">Lagos, Nigeria</p>
                                                                        </div>
                                                                </div>

                                                                <div className="hometenant_water_transact">
                                                                    <div className="water_case">
                                                                        <p className="water_case_text">Water Bill</p>
                                                                    </div>
                                                                </div>

                                                                <div className="hometenant_amount_transact">
                                                                    <div className="amount_case">
                                                                        <div className="case_amount">
                                                                            <p className="amount_case_text">+</p>
                                                                            <p className="amount_case_text2">₦ 40,000</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div className="hometenant_status_transact">
                                                                    <div className="status_case">
                                                                        <div className="case_status">
                                                                            <p className="status_case_text">Successful</p>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <img className="hometenant_status_img" src={process.env.PUBLIC_URL+"arrow-right.svg"} alt="arrow-right.png" />

                                                        </div>
                                                </div>
                                                
                                            <a href={process.env.PUBLIC_URL+"tenantutility"} className="hometenant_status_btn"><p className="hometenant_status_btn_text">Load more</p></a>
                                </div>
                        </div>
                    </div>
    )
};

export default HomeTenant;