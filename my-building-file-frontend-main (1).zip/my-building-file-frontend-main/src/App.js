import React from "react";


import {
  Route,
  createBrowserRouter,
  createRoutesFromElements,
  RouterProvider,
} 


from "react-router-dom";
import Layout from "./components/Layout/Layout";
import LoginPage from "./pages/LoginPage/LoginPage";
import Password from "./pages/LoginPage/Password";
import Password2 from "./pages/LoginPage/Password2";
import Password3 from "./pages/LoginPage/Password3";
import RegisterPage from "./pages/RegisterPage/RegisterPage";
import WelcomePage from "./pages/WelcomePage/WelcomePage";
import RegistrationSuccess from "./pages/RegistrationSucessPage/RegistrationSucess";
import SelectUser from "./pages/SelectUser/SelectUser";
import SelectUsertwo from "./pages/SelectUser/SelectUsertwo";
import SelectUserthree from "./pages/SelectUser/SelectUserthree";
import HomeLandlord from "./pages/Tenants/HomeLandlord"
import HomeLandlord2 from "./pages/Tenants/HomeLandlord2";
import Tenant from "./pages/Tenants/Tenant";
import Tenant2 from "./pages/Tenants/Tenant2";
import Properties from "./pages/Tenants/Properties";
import Properties2 from "./pages/Tenants/Properties2";
import Properties3 from "./pages/Tenants/Properties3"
import Properties4 from "./pages/Tenants/Properties4"
import Messages from "./pages/Tenants/Messages";
import Messages2 from "./pages/Tenants/Messages2";
import Utility from "./pages/Tenants/Utility";
import Wallet from "./pages/Tenants/Wallet";
import Wallet2 from "./pages/Tenants/Wallet2";
import Referral from "./pages/Tenants/Referral";
import Profile from "./pages/Tenants/Profile";
import Profile2 from "./pages/Tenants/Profile2";
import Profile3 from "./pages/Tenants/Profile3";
import TenantRegistration from "./pages/HomeLandlord/TenantRegistration";
import TenantRegistration2 from "./pages/HomeLandlord/TenantRegistration2";
import TenantRegistration3 from "./pages/HomeLandlord/TenantRegistration3";
import HomeTenant from "./pages/HomeLandlord/HomeTenant";
import TenantProperties from "./pages/HomeLandlord/TenantProperties";
import TenantProperties2 from "./pages/HomeLandlord/TenantProperties2";
import TenantProperties3 from "./pages/HomeLandlord/TenantProperties3";
import TenantMessages from "./pages/HomeLandlord/TenantMessages";
import TenantMessages2 from "./pages/HomeLandlord/TenantMessages2";
import TenantUtility from "./pages/HomeLandlord/TenantUtility";
import TenantProfile from "./pages/HomeLandlord/TenantProfile";
import TenantProfile2 from "./pages/HomeLandlord/TenantProfile2";
import TenantProfile3 from "./pages/HomeLandlord/TenantProfile3";
import Modal2 from "./pages/Modals/Modal2";
import Modal3 from "./pages/Modals/Modal3";
import Modal4 from "./pages/Modals/Modal4";
import Modal5 from "./pages/Modals/Modal5";
import Modal6 from "./pages/Modals/Modal6";
import Modal7 from "./pages/Modals/Modal7";
import Modal8 from "./pages/Modals/Modal8";
import Modal9 from "./pages/Modals/Modal9";
import Modal10 from "./pages/Modals/Modal10";
import ModalPassword from "./pages/Modals/ModalPassword";


const routes = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<Layout />}>
      <Route index element={<SelectUser />} />
      <Route path="/signup" element={<LoginPage />} />
      <Route path="/resetpassword" element={<Password />} />
      <Route path="/resetpassword2" element={<Password2 />} />
      <Route path="/resetpassword3" element={<Password3 />} />
      <Route path="/createpassword" element={<RegisterPage />} />
      <Route path="/registration" element={<RegistrationSuccess />} />
      <Route path="/login" element={<WelcomePage />} />
      <Route path="/selectuser2" element={<SelectUsertwo />} />
      <Route path="/selectuser3" element={<SelectUserthree />} />
      <Route path="/homelandlord" element={<HomeLandlord />} />
      <Route path="/homelandlord2" element={<HomeLandlord2 />} />
      <Route path="/tenant" element={<Tenant />} />
      <Route path="/tenant2" element={<Tenant2 />} />
      <Route path="/properties" element={<Properties />} />
      <Route path="/properties2" element={<Properties2 />} />
      <Route path="/properties3" element={<Properties3 />} />
      <Route path="/properties4" element={<Properties4 />} />
      <Route path="/messages" element={<Messages2 />} />
      <Route path="/messages2" element={<Messages />} />
      <Route path="/utility" element={<Utility />} />
      <Route path="/wallet2" element={<Wallet />} />
      <Route path="/wallet" element={<Wallet2 />} />
      <Route path="/referral" element={<Referral />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/profile2" element={<Profile2 />} />
      <Route path="/profile3" element={<Profile3 />} />
      <Route path="/profile3" element={<Profile3 />} /> 
      <Route path="/tenantregistration" element={<TenantRegistration />} />
      <Route path="/tenantregistration2" element={<TenantRegistration2 />} />
      <Route path="/tenantregistration3" element={<TenantRegistration3 />} />
      <Route path="/hometenant" element={<HomeTenant />} />
      <Route path="/tenantproperties" element={<TenantProperties />} />
      <Route path="/tenantproperties2" element={<TenantProperties2 />} />
      <Route path="/tenantproperties3" element={<TenantProperties3 />} />
      <Route path="/tenantmessages" element={<TenantMessages2 />} />
      <Route path="/tenantmessages2" element={<TenantMessages />} />
      <Route path="/tenantutility" element={<TenantUtility />} />
      <Route path="/tenantprofile" element={<TenantProfile />} />
      <Route path="/tenantprofile2" element={<TenantProfile2 />} />
      <Route path="/tenantprofile3" element={<TenantProfile3 />} />
      <Route path="/modalpassword" element={<ModalPassword />} />
      <Route path="/modal" element={<Modal2 />} />
      <Route path="/modal1" element={<Modal3 />} />
      <Route path="/modal2" element={<Modal4 />} />
      <Route path="/modal3" element={<Modal5 />} />
      <Route path="/modal4" element={<Modal6 />} />
      <Route path="/modal5" element={<Modal7 />} />
      <Route path="/modal6" element={<Modal8 />} />
      <Route path="/modal7" element={<Modal9 />} />
      <Route path="/modal8" element={<Modal10 />} />
    </Route>
  )
);

const App = () => <RouterProvider router={routes} />;

export default App;

