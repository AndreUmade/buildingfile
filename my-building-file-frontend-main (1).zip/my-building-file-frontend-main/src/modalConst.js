 import React from "react";
 import { useState } from "react";
 import axios from "axios";
 const url = 'http://admin.mybuildingfile.com/api/v1/manager/register';
// Accept : 'application/json'

 
 export const Register = () => {
    
    
  const [first_name, setName] = useState('')
  const [last_name, setLast] = useState('')
  const [email, setEmail] = useState('')
  const [gender, setGender] = useState('')
  const [address, setAddress] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const resp = await axios.post(url, {first_name,last_name,email,gender,address,phone,password});
      console.log(resp.data);
    } catch (error){
      console.log(error.response);
    }
  };
  
 };